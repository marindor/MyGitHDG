import java.util.Arrays;

public class test1111 {
	public static void main(String[] args) {
	
		int[] data = {1,2,3,4} ;
		System.out.println("=============");
		for(int i=0;i<data.length;i++) {
			data[i]*=3;
			System.out.println(data[i]);
		}
		System.out.println("=============");
		int[] data2 = {-8,2,7,5,-3,5,0,1} ;
			Arrays.sort(data2);
			System.out.println("min : " + Integer.toString(data2[0]));
			System.out.println("min : " + Integer.toString(data2[data2.length-1]));
		}		
}
