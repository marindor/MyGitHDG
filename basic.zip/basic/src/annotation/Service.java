package annotation;

import java.lang.reflect.Method;

public class Service {
	@PrintAnnotation
	public void RUN() {
		System.out.println("실행1");
	}
	
	@PrintAnnotation("***")
	public void JUMP() {
		System.out.println("실행2");
	}
	
	@PrintAnnotation(value="###", number=7)
	public void FIRE() {
		System.out.println("실행3");
	}	
	
	public static void main(String[] args) {
		Method[] m = Service.class.getDeclaredMethods();
		
		for(Method method: m) {
			if(method.isAnnotationPresent(PrintAnnotation.class)) {
				System.out.println("======================");
				PrintAnnotation pw = method.getAnnotation(PrintAnnotation.class);
				System.err.println(method.getName());
				for(int i=0;i<pw.number();i++) {
					System.out.println(pw.value());
				}
			}
		}
		
	}

}
