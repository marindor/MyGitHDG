package annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

//@Target(ElementType.TYPE)
//TYPE은 곧 클래스, "Target은 클래스이다"
@Target( {ElementType.TYPE, ElementType.FIELD, ElementType.METHOD } )
//여러 개를 매개변수로 넣을 시 () 안에 중괄호{} 필요
@Retention(RetentionPolicy.RUNTIME) //정책실행 시점이나 기간

public @interface PrintAnnotation {
	//element를 멤버로 가질 수 있다.
	//코드에 외부의 값을 입력받도록 door 기능을 가지고 있다.
	//각 element는 type/name으로 구분, default값도 가능하다.
	// element name 뒤에는 마치 method처럼 name()해야 한다.
	
	String value() default "-";
	
	int number() default 3; //number를 지정안하면 5값 들어감.

}
