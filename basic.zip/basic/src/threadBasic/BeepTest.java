package threadBasic;

import java.awt.Toolkit;

public class BeepTest implements Runnable{
	@Override
	public void run() {
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		for(int i=0;i<5;i++) {
			System.out.println("beep");
			toolkit.beep();//스피커 있으면 "띵~"소리난다.
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}//1초마다.
		}
	}
	
}
