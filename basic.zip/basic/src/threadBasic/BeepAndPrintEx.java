package threadBasic;

import java.awt.Toolkit;

public class BeepAndPrintEx {
	public static void main(String[] args) {
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		
		for(int i=0;i<5;i++) {
			System.out.println("beep");
			toolkit.beep();//스피커 있으면 "띵~"소리난다.
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}//1초마다.
		}
		
		for(int i=0;i<5;i++) {
			System.out.println("hi");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}//1초마다.
		}		

	}
	
}
