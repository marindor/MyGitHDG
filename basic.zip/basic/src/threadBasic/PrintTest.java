package threadBasic;

public class PrintTest {
	public static void main(String[] args) {
		
		Runnable beepTest = new BeepTest();
		Thread thread = new Thread(beepTest);
		
		thread.start();
		
		for(int i=0;i<5;i++) {
			System.out.println("hi");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}//1초마다.
		}		
		
	}

}
