package threadBasic;

public class User1 extends Thread{
	Calculator cal;
	
	
	public void setCal(Calculator cal) {
		this.setName("user1_thread");
		this.cal = cal;
	}


	@Override
	public void run() {
		cal.setMemory(100);
	}
}
