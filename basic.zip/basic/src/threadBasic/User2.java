package threadBasic;

public class User2 extends Thread{
	Calculator cal;
	
	
	public void setCal(Calculator cal) {
		this.setName("user2_thread");
		this.cal = cal;
	}


	@Override
	public void run() {
		cal.setMemory(50);
	}
}
