package threadBasic;

public class BeepPrintEx3 {
	public static void main(String[] args) {
		Thread thread = new BeepThread();
		Thread thread2 = new BeepThread2();
		
		System.out.println(thread.getName());
		System.out.println(thread2.getName());
		
		thread2.setName("hahaha");
		System.out.println(thread2.getName());
	}
}
