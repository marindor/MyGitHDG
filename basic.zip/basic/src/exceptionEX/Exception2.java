package exceptionEX;

public class Exception2 {
	public static void main(String[] args) {
		
		try {
			findClass();
		}catch(ClassNotFoundException e) {
			System.out.println("그런 클래스는 없습니다.");
		}
	}
	
	
	static void findClass() throws ClassNotFoundException{
		Class classInfo = Class.forName("java.lang.Stringxxxxxxxx");
		System.out.println(classInfo.getName());
	}
	
}