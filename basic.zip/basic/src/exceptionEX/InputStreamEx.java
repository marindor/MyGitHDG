package exceptionEX;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class InputStreamEx {
	public static void main(String[] args) throws IOException {
		InputStream is = System.in; //System은 컴퓨터 자원을 활용을 담는 객체
		Reader reader = new InputStreamReader(is);
		
		int readCharactotCount;
		char charBuffer[] = new char[100];
		
		try {
			//read() 메소드는 더 이상 입력 스트림으로부터 문자를 읽을 수 없다면 -1을 return한다.
			//이것을 이용하면 읽을 수 있는 마지막 문자까지 루프를 돌면서 한 문자씩 읽을 수 있다.
			while( (readCharactotCount=reader.read(charBuffer)) != -1 ) {
				System.out.println(readCharactotCount);
				String data = new String(charBuffer,0,readCharactotCount);
				System.out.println(data);
				System.out.println(readCharactotCount);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			reader.close();
		}
		
	}
}
