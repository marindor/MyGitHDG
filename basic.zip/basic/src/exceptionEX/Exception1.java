package exceptionEX;

public class Exception1 {
	public static void main(String[] args) {
//		String data = null;
//		
//		
//		try {
//			System.out.println(data.toString());//에러 의심 구문을 try에 넣고 실험한다.	
//		}catch(Exception e) {
//			System.out.println("data가 null이네요.");
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//		}
		

		
		try {
			System.out.println(args[0]);//hahahaha!
			System.out.println(args[1]);//you
			System.out.println(args[2]);//can	
			System.out.println(args[3]);//use
			System.out.println(args[4]);//args
			System.out.println(args[5]);//존재하지 않는 값			
			
		}catch(Exception e) {
			System.out.println("입력 args[]가 size를 넘쳤어요.");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}		
		
	}
}
