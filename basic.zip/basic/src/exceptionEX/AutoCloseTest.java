package exceptionEX;

public class AutoCloseTest {
	
	//try with - resources 문을 사용시 try 문의 괄호() 안에 리소스 선언
	public static void main(String[] args) {
		
		//자동으로 AutoCloseObj를 닫기 위해 아래 생성자로 객체를 만든 것이다.
		AutoCloseObj obj = new AutoCloseObj();
		
		try(obj) {
			System.out.println("뭔가 동작코드 자리임");
			throw new Exception();//강제 예외 실행 코드문
		}catch(Exception e) {
			System.out.println("예외 발생!");
		}
	}
}
