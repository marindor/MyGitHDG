package interface_complex;

public interface Calc {
	//상추디정
	
	//상속
	final static double PI = 3.14;
	static final int Error = -999999999;
	
	//추상
	abstract int add(int num1, int num2);
	abstract int substract(int num1, int num2);
	abstract int times(int num1, int num2);
	abstract int divide(int num1, int num2);
	
	//디폴트
	//정적
}
