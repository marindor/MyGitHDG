package interface_complex;

import java.io.IOException;

public class ScheduleTest {
	public static void main(String[] args) throws IOException {
		//문자열 입력은 scanner class 이용
		//입력받고자 할 때 System.in.read()
		
		int ch = System.in.read();//문자 한개 입력시
		Schedule schedule = null;
		
		//return 1. 반환하다. 2. 종료하다. 
		
		System.out.println((char)ch);
		
		if(ch=='R' || ch=='r') {
			schedule = new RoundRobin();
		}else if(ch=='L' || ch=='l') {
			schedule = new LeastJob();
		}else if(ch=='P' || ch=='p') {
			schedule = new PriorityAllocation();
		}else {
			System.out.println("지원하지 않는 기능");
			return;
		}
		schedule.getNextCall();
		schedule.sendCallAgent();
	}
}
