package interface_complex;

public class CompleteCalcTest {
	public static void main(String[] args) {
		int num1=10;
		int num2=5;
		
		CompleteCalc c = new CompleteCalc();
		
		int res1 = c.add(num1, num2);
		System.out.println(res1);
		int res2 = c.substract(num1, num2);
		System.out.println(res2);
		int res3 = c.times(num1, num2);
		System.out.println(res3);
		int res4 = c.divide(num1, num2);
		System.out.println(res4);
		c.showInfo();
	}
}
