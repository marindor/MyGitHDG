package interface_complex;

public class PriorityAllocation implements Schedule{
	@Override
	public void getNextCall() {
		System.out.println("등급높은 고객 전화 먼저 가져오기");
		
	}
	@Override
	public void sendCallAgent() {
		System.out.println("등급높은 고객 전화 먼저 배분하기");
		
	}	

}
