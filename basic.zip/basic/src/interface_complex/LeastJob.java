package interface_complex;

public class LeastJob implements Schedule {
	@Override
	public void getNextCall() {
		System.out.println("순서대로 대기열에서 가져오기");
		
	}
	@Override
	public void sendCallAgent() {
		System.out.println("대기가 가장 적은 상담원에게 할당");
		
	}	

}
