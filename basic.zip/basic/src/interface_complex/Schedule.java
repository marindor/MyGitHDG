package interface_complex;

public interface Schedule {
	abstract void getNextCall();
	abstract void sendCallAgent();
}
