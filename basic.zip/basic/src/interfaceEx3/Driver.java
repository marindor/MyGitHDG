package interfaceEx3;

public class Driver {
	
	void selectAndRun(Vehicle vehicle) {
		vehicle.drive();
	}
}
