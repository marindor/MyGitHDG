package interfaceEx3;

public class VehicleEx {
	
	public static void main(String[] args) {
		Driver ps1 = new Driver();
		ps1.selectAndRun(new Bus());
		
		Driver ps2 = new Driver();
		ps2.selectAndRun(new Taxi());
	}
}
