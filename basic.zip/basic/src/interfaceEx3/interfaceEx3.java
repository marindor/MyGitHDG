package interfaceEx3;

public interface interfaceEx3 {

}
