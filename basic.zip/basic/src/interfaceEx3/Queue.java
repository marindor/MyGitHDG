package interfaceEx3;

public interface Queue {
	abstract void enQueue(String title);
	abstract String deQueue();
	abstract int getSize();
}
