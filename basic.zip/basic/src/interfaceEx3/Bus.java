package interfaceEx3;

public class Bus implements Vehicle{
	
	@Override
	public void drive() {
		System.out.println("버스가 달린다.");
	}
}
