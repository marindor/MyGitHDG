package interfaceEx3;

public class QueueTest {
	public static void main(String[] args) {
		Queue que = new BookShelf();
		//자식class로 생성하여 interface로 자동형변환
		
		
		que.enQueue("태백산맥1");
		que.enQueue("태백산맥2");
		que.enQueue("태백산맥3");
		que.enQueue("태백산맥4");
		
		Shelf shelf = new BookShelf();
		//자식class로 생성하여 부모 Shelf로 자동형변환
		int cnt = que.getSize();
		System.out.println(cnt);
		
		System.out.println(que.deQueue());
		int cnt2 = que.getSize();
		System.out.println(cnt2);

		System.out.println(que.deQueue());
		int cnt3 = que.getSize();
		System.out.println(cnt3);
		
		
		System.out.println(que.deQueue());
		System.out.println(que.deQueue());
		int cnt4 = que.getSize();
		System.out.println(cnt4);
	}

}
