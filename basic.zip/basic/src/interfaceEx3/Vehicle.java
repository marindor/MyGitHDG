package interfaceEx3;

public interface Vehicle {
	//상추디정
	
	//상
	
	//추
	abstract void drive();
	
	//디

	//정
}
