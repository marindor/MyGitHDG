package interfaceEx3;

public class Taxi implements Vehicle{
	
	@Override
	public void drive() {
		System.out.println("택시가 달린다.");
	}
}
