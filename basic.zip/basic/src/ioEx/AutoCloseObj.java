package ioEx;

public class AutoCloseObj implements AutoCloseable{

	@Override
	public void close() throws Exception {
		System.out.println("close() 자동 실행, 사용 resource 해제");
		
	}
}
