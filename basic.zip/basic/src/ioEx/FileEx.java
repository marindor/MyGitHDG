package ioEx;

import java.io.File;
import java.io.IOException;

public class FileEx {
	public static void main(String[] args) {
		
//		File dir1 = new File("D:/ex/test");
//		if(!dir1.exists()) {
//			Boolean bool = dir1.mkdir();
//			System.out.println(bool);			
//		}else {
//			System.out.println("이미 폴더가 존재합니다.");
//		}

		
		File file1 = new File("D:/ex/test/haha2.txt");
		
		if(!file1.exists()) {
			try {
				boolean bool2 = file1.createNewFile();
				System.out.println(bool2);
			}catch(IOException e){
				System.out.println(e.getMessage());
			}			
		}else
		{
			System.out.println("이미 파일이 존재합니다.");
		}
		

		
		
		
	}
}
