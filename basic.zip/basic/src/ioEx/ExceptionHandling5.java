package ioEx;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;



public class ExceptionHandling5 implements AutoCloseable {
	public static void main(String[] args) throws Exception {
		
		FileInputStream fis = new FileInputStream("D:/ex/test/a.txt");
		try(fis) {//파일 열기
			int i;
			while((i=fis.read())!=-1) {
				System.out.print((char)i);//파일 읽기
			}
			throw new Exception();//catch 강제 호출
		} catch (Exception e) {
			System.out.println();
			System.out.println("강제호출함");
		}
		System.out.println("파일 열기 - 파일 읽기 - 내용찍기 - 파일 닫기 완료");
		
	}

	@Override
	public void close() throws Exception {
		System.out.println("close() 자동실행(resource 닫음");//파일 닫기
	}
}