package ioEx;

import java.io.FileReader;
import java.io.FileWriter;

public class FileWriterEx2 {
	public static void main(String[] args) throws Exception {
		
		//파일 쓰기
		FileWriter fw = new FileWriter("D:/ex/test3/Oops.txt");//파일 열고
		fw.write("오 이런저런 만만세!");//파일 쓰고
		fw.close();//파일 닫기
		
		System.out.println("===================");;
		
		//방금 쓴 파일을 읽기
		FileReader fr = new FileReader("D:/ex/test3/Oops.txt");//파일 열고
		int i;
		while((i=fr.read())!= -1) { //파일 읽고
			System.out.print((char)i);
		}
		fr.close();//파일 닫기
	}
}
