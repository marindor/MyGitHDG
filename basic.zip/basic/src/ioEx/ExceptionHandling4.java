package ioEx;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;



public class ExceptionHandling4 {
	public static void main(String[] args) throws IOException {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream("D:/ex/test/a.txt");//파일 열기
			int i;
			while((i=fis.read())!=-1) {
				System.out.print((char)i);//파일 읽기
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}finally {
			fis.close(); //파일 닫기
		}
		System.out.println();
		System.out.println("파일 열기 - 파일 읽기 - 내용찍기 - 파일 닫기 완료");
	}
}