package ioEx;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ioEx2 {
	public static void main(String[] args) throws Exception {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream("D:/ex/test/haha.txt");
			int i;
			while((i=fis.read()) != -1) {
				System.out.print((char)i);
			}
		} catch (Exception e) {
			e.getMessage();
		} finally {
			fis.close();
		}
	}
}
