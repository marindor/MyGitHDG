package ioEx;

public class AutoCloseObjTest  implements AutoCloseable{
	public static void main(String[] args) {
		//try - witd - resource
		//try문 괄호()안에 리소스 선언
		AutoCloseObjTest obj = new AutoCloseObjTest();
		try(obj){
			throw new Exception(); //강제로 예외처리 구문, catch 호출
		}catch(Exception e) {
			System.out.println("예외처리 catch 구문 실행");
		}		
	}

	@Override
	public void close() throws Exception {
		System.out.println("close() 자동 실행, 사용 resource 해제");
		
	}
}