package ioEx;
		
import java.io.FileNotFoundException; 
import java.io.FileOutputStream;
import java.io.IOException;
		
public class FileOutputStreamEx1 {
	public static void main(String[] args) {
		System.out.println("출력 시작");
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream("d:/ex/test/output.txt",true); //파일 생성, 이미 있다면 덮어쓰기
			fos.write(65);//파일 수정
			fos.write(66);
			fos.write(67);
			fos.close(); //파일 닫기
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
			System.out.println("출력 완료");			
	}
}
