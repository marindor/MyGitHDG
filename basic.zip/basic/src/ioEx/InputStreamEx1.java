package ioEx;

import java.util.Scanner;

public class InputStreamEx1 {
	public static void main(String[] args) {
		
		//문자열 여러 개 입력 받기
		try {
			Scanner sc = new Scanner(System.in);
			String str1 = sc.next();//문자열 입력
			String str2 = sc.next();//문자열 입력
			String str3 = sc.nextLine();//공백 구분자의 여러 문자열 입력
			System.out.println(str1);
			System.out.println(str2);
			System.out.println(str3);
			
		}catch(Exception e) {
			System.out.println("에러");
			System.out.println(e.getMessage());
		}
	}
}
