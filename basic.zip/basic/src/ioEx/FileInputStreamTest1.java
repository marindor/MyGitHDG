package ioEx;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class FileInputStreamTest1 {
	public static void main(String[] args) throws IOException{
		//파일 읽기
//		FileInputStream fis = null;
//		try {
//			fis = new FileInputStream("D:/ex/test/hoho.txt");
//			int i;
//			while((i=fis.read())!=-1) {
//				System.out.print((char)i);
//			}			
//		} catch ( Exception e) {
//			System.out.println(e.getMessage());
//		}finally {
//			fis.close();
//		}
		
		
		//한글도 읽기가 가능하다.
		//예외처리가 필요없다.
		FileReader fr = new FileReader("D:/ex/test/hoho.txt");
		int i;
		while((i=fr.read())!=-1) {
			System.out.print((char)i);
		}			

	}
}
