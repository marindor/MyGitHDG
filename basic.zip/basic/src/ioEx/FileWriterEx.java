package ioEx;

import java.io.FileWriter;

public class FileWriterEx {
	public static void main(String[] args) throws Exception{
		
		FileWriter fs = new FileWriter("D:/ex/test3/kaka.txt");
		
		fs.write("hi hello 이놈");
		
		fs.close();
	}
}
