
public class FunEx1 {
	public static void main(String[] args) {
		func1(5);
	}
	
	public static void func1(int n) {
		if(n==1) {
			return;
		}
		System.out.println("hi");
		func1(n-1);
	}
}
