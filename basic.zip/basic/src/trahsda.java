
public class trahsda {
	public static void main(String[] args) {
		String path = "D:/file_repo/book1.png";
		System.out.println("첫 /의 위치"+path.indexOf("/"));
		path.lastIndexOf("/");
		System.out.println("마지막 /의 위치"+path.lastIndexOf("/"));
	}
}
