
public class IfTest {
	//필생매
	//필
	//생
	//매
	public static void main(String[] args) {		
		int score = 190;
		if(score>=90 && score<=100){
			System.out.println('A');
		}else if(score>=80 && score<90) {
			System.out.println('B');
		}else if(score>=70 && score<80) {
			System.out.println('C');
		}else if(score>=0&& score<70 ){
			System.out.println('D');
		}else {
			System.out.println("범위 밖이다.");
		}
	}
}
