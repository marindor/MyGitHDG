package interface2Ex;

public class RemoconEX {
	public static void main(String[] args) {
		Remocon rc = null;
		rc = new audio();
		rc.turnOn();
		rc.setVolume(-50);
		int volume = rc.getVolume();
		System.out.println(volume);
		rc.turnOff();;
		
		//인터페이스 접근1
		System.out.println("--------------");
		rc = new television();
		rc.turnOn();
		rc.setVolume(150);
		volume= rc.getVolume();
		System.out.println(volume);
		rc.turnOff();
		System.out.println("--------------");
		
		//인터페이스 접근2
		television tv = new television();
		tv.turnOn();
		tv.setVolume(10);
		volume = tv.getVolume();
		System.out.println(volume);
		tv.turnOff();
		System.out.println("--------------");
		
		
		
		
		
		
	}
}
