package interface2Ex;

public interface Remocon {
	//상추디정
	//상수
	final static int MaxVolume=100;
	final static int MinVolume=0;
	//추상
	abstract void turnOn();
	abstract void turnOff();
	abstract void setVolume(int volume);
	abstract int getVolume();
	//디폴트
	
	//정적
	

}
