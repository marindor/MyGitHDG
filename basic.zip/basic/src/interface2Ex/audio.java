package interface2Ex;

public class audio implements Remocon {

	private int volume;
	
	@Override
	public void turnOn() {
		System.out.println("오디오 켰다.");
		
	}

	@Override
	public void turnOff() {
		System.out.println("오디오 껐다.");
		
	}

	@Override
	public void setVolume(int volume) {
		if(volume>Remocon.MaxVolume) {
			this.volume=Remocon.MaxVolume;
		}else if(volume<Remocon.MinVolume) {
			this.volume=Remocon.MinVolume;
		}else {
			this.volume= volume;
		}
	}
	@Override
	public int getVolume() {
		return this.volume;
	}	

}
