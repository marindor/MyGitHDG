package OperatorEX;

public class Book88p {
	public static void main(String[] args) {
		//Q1
		System.out.println("Q1-----------");
		int myAge = 23;
		int teacherAge =38;
		
		boolean value = (myAge > 25);
		System.out.println(value);
		
		System.out.println(myAge <=25);
		System.out.println(myAge == teacherAge);
		
		char ch;
		ch = (myAge > teacherAge) ? 'T' : 'F';
		
		System.out.println(ch);
		
		//Q2
		System.out.println("Q2-----------");
		int num;
		num = -5+3*10/2;
		System.out.println(num);
		
		//Q3
		System.out.println("Q3-----------");
		int num1=10;
		
		System.out.println(num1); //10
		System.out.println(num1++); //11아님! 우선 한 줄코드를 먼저 실행한 후 ++를 실행하라. 
		System.out.println(num1); //그래서 여기서는 11! 위에서 num1++한 결과가 여기서의 num1이다.
		System.out.println(--num1); //10
		
		//Q4
		System.out.println("Q4-----------");
		int num2=10;
		int num3=20;
		boolean result;
		
		result = ((num2>10)&&(num3>10));
		System.out.println(result); //false
		result = ((num2>10)||(num3>10)); 
		System.out.println(result); //true
		System.out.println(!result); //false
		
		//Q5
		System.out.println("Q5-----------");
		int num5=2;
		int num6=10;
		
		System.out.println(num5 & num6); //0010 & 1010 = 0010 = 2
		System.out.println(num5 | num6); //1010 = 10
		System.out.println(num5 ^ num6); //xor 1000 = 8
		System.out.println(~num5);  //-3
		
		//Q6
		System.out.println("Q6-----------");
		int num10 = 8;
		System.out.println(num10 += 10); //18 
		System.out.println(num10 -= 10); //18-10=8
		System.out.println(num10 >>= 2); //1000>>2 = 0010 = 2
		
		//Q7
		System.out.println("Q7-----------");
		int num100=10;
		int num200=20;
		int result100= (num100>=10)?num200+10 : num200-10;
		//30
		System.out.println(result100);
	}
}
