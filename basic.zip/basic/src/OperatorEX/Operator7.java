package OperatorEX;

public class Operator7 {//조건 연산자
	public static void main(String[] args) {
		//조건 연산자
		//~이면  ~아니면
		//논리 연산자 , 참/거짓
		                 //조건 ? 참 결과 : 거짓 결과
		System.out.println(true ? "hi" :"bad");//문자열
		System.out.println(false ? 'o' :'x');//문자
		System.out.println(true ? "haha" : "hoho");
		System.out.println(2>1 ? "2" : "1");
		
		char result = 2<1 ? 'o' : 'x';
		System.out.println(result);
	}
}
