package OperatorEX;

public class Operator8 {
	public static void main(String[] args) {
		//비트 연산자 6마리
		//ampersand, pipe, caret, tilder
		// & | ^ ~ 
		// <<   >>
		
		System.out.println(5 & 4);
		System.out.println(78 & 39);//0000110  4+2 = 6
		//78 : 100 1110
		//39 : 010 0111
		System.out.println(78 | 39);//1101111  64+32+8+4+2+1 = 111
		
		
		//caret ^ 은 XOR 이다.
		//참참 = 거짓
		//거짓거짓 = 거짓
		//참거짓 = 참
		//거짓참 = 참
		//다를때만 참이다.
		System.out.println(78 ^ 39);//caret 청개구리 연산자
		//78 : 100 1110
		//39 : 010 0111
		//     110 1001 (105)
		
		//tilder ~  는 NOT이다.
		System.out.println(~5);
		//5 :  0000 0101
		//~5 : 1111 0010 (2인데 -6나오네???)
		//NOT연산은 정수에 +1 을하고 마이너스를 붙이는 연산이다.
		//~5는 5+1에 -마이너를 붙이는 연산이다.
		//원래 0000 0000 0000.....0000 0101 을 not하면
		//1111 1111 1111....1111 1010 이다. 어마무시한 수이다.
		//그래서 앞에 1111로 꽉 차면 음수라고 생각하는게 기본 규칙이고
		//거기에 1010 은 6이다.
		//그래서 -6이다.
		
	
		//shift <<   >>
		System.out.println(4<<2);
		//4 : 100
		//2 : 010
		// 100을 010 만큼 왼쪽으로 shift해라.
		System.out.println(4>>2);
		System.out.println(4<<3);
		
	}
}
