package stringClass;

public class SearchEx {
	public static void main(String[] args) {
		String ssn = "974443-1234567";
		char ch = ssn.charAt(6);//char return. 해당 인덱스 문자 검색
		System.out.println(ch);
		int leng = ssn.length();//int return. 길이 반환
		System.out.println(leng);
		
		String subject = "자바 프로그래밍";
		int ja = subject.indexOf('프'); //int return, 문자의 인덱스 검색
		System.out.println(ja);
		ja = subject.indexOf('타'); //int return, 문자의 인덱스 검색
		System.out.println(ja); //검색 문자가 없을 경우 -1을 내보는 것이 문자열 함수 관습이다.
		//그래서 if문 조거문에 -1을 많이 쓴다.
		if(ja==-1) {
			System.out.println("그 문자는 없다.");
		}
		else {
			System.out.println("그 문자가 있다.");
		}
		
		
		int str = ssn.indexOf("444"); //검색 결과의 첫번째 인덱스 return
		System.out.println(str);
		str = ssn.indexOf("랄랄랄");
		if(str==-1) {
			System.out.println("그 문자는 없다.");
		}
		else {
			System.out.println("그 문자가 있다.");
		}			
		
		
		String aaa = "  아버지가 집에 들어가신다.  ";
		System.out.println(aaa);
		
		aaa = aaa.replace("집", "가방");
		System.out.println(aaa);
		
		aaa= aaa.trim();
		System.out.println(aaa);
		
		String bbb = "i am a boy.";
		bbb = bbb.toUpperCase();
		System.out.println(bbb);
		bbb = bbb.toLowerCase();
		System.out.println(bbb);
				
	}

}
