package stringClass;

import java.io.IOException;

public class Stringclass {
	public static void main(String[] args) throws IOException{
//		byte arr[] = new byte[100];
//	
//		int readBytes = System.in.read(arr);//읽은 바이트 수
//		System.out.println(readBytes);
//		
//		String str = new String(arr,0,readBytes);//arr을 0부터 배열길이까지 문자열로 객체로 생성해서 str에 저장		
//		System.out.println(str);
		
	
//		byte arr[] = {'h','e','l','l','o'};
//		for (byte i : arr) { //byte배열을 byte로 찍기
//			System.out.println(i);
//		}
		
//		String str = new String(arr);
//		System.out.println(str);
//		
//		String str2 = new String(arr,0,arr.length);
//		System.out.println(str2);
//		
//		int readBytes = System.in.read(arr);
//		System.out.println(readBytes);
		
		
	
		
	}
}
