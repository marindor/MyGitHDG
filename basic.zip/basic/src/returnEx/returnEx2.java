package returnEx;

public class returnEx2 {
	public static void main(String[] args) {
		
		System.out.println("1");
		System.out.println("2");
		if(false) {
			System.out.println("3");
		}else {
			System.out.println("4");//코드 종료
			return;
		}
		System.out.println("5");
	}
}
