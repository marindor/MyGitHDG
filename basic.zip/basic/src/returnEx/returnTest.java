package returnEx;

public class returnTest {
	
	static String hellow(){
		return "hellow";
	}
	
	static String test(){
		if(true) {
			return "true retrun!";
		}else {
			return "false return!";
		}
	}	
	
	public static void main(String[] args) {
		returnTest aaa = new returnTest();
		
		if(false) {
			System.out.println("ㅋㅋㅋㅋ");
		}else {
			return;//반환할게 없으면 종료하라.
		}
		
		System.out.println(aaa.hellow());
		System.out.println(aaa.test());
	}
}
