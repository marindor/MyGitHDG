package Oop1;

public class Worrior {
	int stamina;
	int strength;
	int damage;
	String weapon;
	boolean shield;
	
	void atack() {
		switch(weapon) {
		case "sword":
			System.out.println("무기 : sword");
			strength+=2;
			System.out.println("공격력 :" + strength);
			break;
		case "dart" :
			System.out.println("무기 : dart");
			strength+=1;
			System.out.println("공격력 :" + strength);			
			break;
		case "fist" :
			System.out.println("무기 : fist");
			strength+=0;
			System.out.println("공격력 :" + strength);			
			break;
		default:
			System.out.println("무기없음!");
			System.out.println("공격력 :" + strength);			
			break;
		}		
	}
	int defend() {
		if(shield==true) {
			damage=2;
		}
		else {
			damage=4;
		}
		return damage;
	}
	void cure() {
		stamina+=1;
	}
}
