package Oop1;

public class Book {
	String bookid;
	String bookname;
	String publisher;
	int price;
	
	public static void main(String[] args) {
		Book book1 = new Book();
		book1.bookname= "축구의 역사";
	}
}
