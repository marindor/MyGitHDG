package Oop1;

public class Car1 {
	//main method 없음!
	int wheel;
	void roll() {
		System.out.println("굴러간다.");
	}
}
