package Oop1;

public class WorriorEx {
	public static void main(String[] args) {
		Worrior worriorA = new Worrior();
		Worrior worriorB = new Worrior();
		
		worriorA.strength=2;
		worriorB.strength=3;
		
		worriorA.stamina=10;
		worriorB.stamina=7;
		
		worriorA.shield=false;
		worriorB.shield=true;		
		
		worriorA.weapon="sword";
		worriorB.weapon="dart";
		
		int actionA=13211;
		int actionB=23121;
		int A_turn;
		int B_turn;
			for(int limit_time=1;limit_time<=5;limit_time++) {
					A_turn=actionA % 10;
					if(limit_time == 1) {
						System.out.println("1턴");
						System.out.println("A전사 체력 : "+worriorA.stamina);
						worriorA.atack();
						System.out.println("A공격 : "+worriorA.strength+"의 힘으로 떄림.");
					}
					else if(limit_time==2){
						System.out.println("2턴");
						System.out.println("A전사 체력 : "+worriorA.stamina);
						System.out.println("방어 : "+worriorA.defend());
						System.out.println("입은 피해 : "+ "("+ worriorB.strength +"-"+worriorA.defend()+")"+"="+ ((worriorB.strength-worriorA.defend())));
						worriorA.stamina = worriorA.stamina-(worriorB.strength-worriorA.defend());
						System.out.println("A전사 체력 : "+ worriorA.stamina+"가 되었다.");
						
					}
					else {
//						System.out.println("A전사 부상치료!!!");
					}
					actionA = actionA/10;
					
					B_turn=actionB % 10;
					if(limit_time == 1) {
						System.out.println("1턴");
						System.out.println("B전사 체력 : "+ worriorB.stamina);
						worriorB.defend();
						System.out.println("방어 : "+worriorB.defend());
						System.out.println("입은 피해 : "+ "("+ worriorA.strength +"-"+worriorB.defend()+")"+"="+ ((worriorA.strength-worriorB.defend())));
						worriorB.stamina = worriorB.stamina-(worriorA.strength-worriorB.defend());
						System.out.println("B전사 체력 : "+ worriorB.stamina+"가 되었다.");
						System.out.println("**********************");
						System.out.println("이제 B전사 공격!!");
						worriorB.atack();
						System.out.println("B공격 : "+worriorB.strength+"의 힘으로 때림.");
						System.out.println("======================");
					}
					else if(limit_time==2){
					}
					else {
//						System.out.println("B전사 부상치료!!!");
					}
					actionB = actionB/10;	
					
					switch(actionA) {
					case 1:
						break;
					case 2:
						break;
					case 3:
						break;
					default :
						break;
					}			
		
					switch(actionB) {
					case 1:
						break;
					case 2:
						break;
					case 3:
						break;
					default :
						break;
					}						
			}
		}
}
