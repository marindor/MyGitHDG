package Oop1;

public class AnimalEx {
	public static void main(String[] args) {
		Animal animal = new Animal();
		animal.name="복실이";
		animal.sound="멍멍멍";
		animal.age=2;
		animal.race="강아지";
		animal.weight=3;
		System.out.println("나는 애완동물을 키운다.");
		System.out.println("이름은"+ animal.name + "이고 나이는" + animal.age + "살이다.");
		System.out.println(animal.race + "이며 몸무게는 " + animal.weight + "kg이다.");
		System.out.println("소리를 낼 때에는");
		animal.speak();
		System.out.println("이런다.");
		System.out.print("또한 이놈은");
		if(animal.wing==true) {
			animal.fly();
		}
		System.out.println("가끔씩 ");
		animal.bePainful();
		System.out.print("그럴 때마다 ");
		animal.hide();
		
		
		
		System.out.print("또 있다.");
		Animal animal1 = new Animal();
		animal1.name="턱시도";
		animal1.sound="야오오옹";
		animal1.age=1;
		animal1.race="고양이";
		animal1.weight=2;
		animal1.checkup=2;
		System.out.println("이름은"+ animal1.name + "이고 나이는" + animal1.age + "살이다.");
		System.out.println("얘는 총 "+animal1.checkup+"번의 건강검사를 받았는데");
		for(int i=0; i<animal1.checkup; i++) {
			if(i==0) {
				System.out.println("갓태어났을 때는 허약했다");
			}
			else if(i==1) {
				System.out.println("두 번째는 건강이 많이 좋아졌다.");
			}
		}
		System.out.print("현재는 목줄을 풀어줬더니");
		animal1.run();
	}

}
