package Oop1;

public class OopEx2 {
	public static void main(String[] args) {
		
		String str=null;
//		System.out.println(System.identityHashCode(str));
//		System.out.println(str);
//		
//		System.out.println(str==null);
//		System.out.println(str.equals(null));
//		
//		
		System.out.println(str==null);
//		System.out.println(str.equals(null));
//		
//		str="nice";
//		System.out.println(str.equals(null));
//		
		
//		if(str==null) {
//			System.out.println("아무곳도 가리키지 않는다.");
//		}
//		else {
//			System.out.println("어딘가를 가리킨다.");
//		}
//		
//		if(str.equals(null) {
//			System.out.println("아무곳도 가리키지 않는다.");
//		}
//		else {
//			System.out.println("어딘가를 가리킨다.");
//		}
	}
}
