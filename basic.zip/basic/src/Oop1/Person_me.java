package Oop1;

public class Person_me {
	public static void main(String[] args) {
		Person me = new Person();
		me.height = 180;
		me.weight = 97.5;
		me.name = "Han, Donggyun";
		me.gender = 'M';
		me.married = false;
		me.hairColor = "짙은 갈색";
		me.race = "아시아인";
		System.out.println(me.name + "의 키는 " + me.height + "cm이다");
		System.out.println(me.name + "의 몸무게는 " + me.weight + "kg이다");
		if (me.gender == 'M') {
			System.out.println(me.name + "는 남자이다.");
		} else if (me.gender == 'F') {
			System.out.println(me.name + "는 여자이다");
		} else {
			System.out.println(me.name + "의 성별은 비밀이다.");
		}
		if (me.married == true) {
			System.out.println(me.name + "는 결혼했다.");
		} else {
			System.out.println(me.name + "는 미혼이다.");
		}
		System.out.println(me.name + "의 머리칼은 " + me.hairColor + "이다");
		System.out.println(me.name + "는 " + me.race + "이다");
		System.out.println(me.name + "은/는/이/가");
		me.sleep();
		me.eat();
		me.speak();
		me.hear();
		me.run();
		me.walk();
		System.out.println();
		System.out.println();

		Person you = new Person();
		you.height = 165;
		you.weight = 57.5;
		you.name = "merry ";
		you.gender = 'F';
		you.married = false;
		you.hairColor = "파란색";
		you.race = "이태리인";
		System.out.println(you.name + "의의 키는 " + you.height + "cm이다");
		System.out.println(you.name + "의의 몸무게는 " + you.weight + "kg이다");
		if (you.gender == 'M') {
			System.out.println(you.name + "는 남자이다.");
		} else if (you.gender == 'F') {
			System.out.println(you.name + "는 여자이다");
		} else {
			System.out.println(you.name + "의 성별은 비밀이다.");
		}
		if (you.married == true) {
			System.out.println(you.name + "는 결혼했다.");
		} else {
			System.out.println(you.name + "는 미혼이다.");
		}
		System.out.println(you.name + "은/는/이/가");
		you.sleep();
		you.eat();
		you.speak();
		you.hear();
		you.run();
		you.walk();
		System.out.println();
		System.out.println();

		Person friend1 = new Person();
		friend1.height = 171;
		friend1.weight = 68.1;
		friend1.name = "jery ";
		friend1.gender = 'F';
		friend1.married = false;
		friend1.hairColor = "갈색";
		friend1.race = "이태리인";
		System.out.println(friend1.name + "의 키는 " + friend1.height + "cm이다");
		System.out.println(friend1.name + "의 몸무게는 " + friend1.weight + "kg이다");
		if (friend1.gender == 'M') {
			System.out.println(friend1.name + "는 남자이다.");
		} else if (friend1.gender == 'F') {
			System.out.println(friend1.name + "는 여자이다");
		} else {
			System.out.println(friend1.name + "의 성별은 비밀이다.");
		}
		if (friend1.married == true) {
			System.out.println(friend1.name + "는 결혼했다.");
		} else {
			System.out.println(friend1.name + "는 미혼이다.");
		}
		System.out.println(friend1.name + "은/는/이/가");
		friend1.sleep();
		friend1.eat();
		friend1.speak();
		friend1.hear();
		friend1.run();
		friend1.walk();
	}
}
