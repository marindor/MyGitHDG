package Oop1;

public class Car1_1 {
	int wheel;
	void roll(){
		System.out.println("rolling!");
	}
}
