package Oop1;

public class Calculator {
	void menu1() {//입출력 없음
		System.out.println("1. 프림과 설탕없는 커피");
	}
	void menu2(String spoon) {//입력만 있음
		System.out.println(spoon);
	}
	String menu3() {//출력만 있음
		return "3. 프림만 있는 커피";
	}
	String menu4(String sugar) {//입력, 출력 있음
		System.out.print(sugar+"도 있고 ");
		return "프림도 있는 커피";
		
	}	

}
