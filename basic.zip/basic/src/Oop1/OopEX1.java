package Oop1;

public class OopEX1 {
	public static void main(String[] args) {
		
		String name1 = "홍길동";
		String name2 = new String("홍길동");
		
		System.out.println(name1.equals(name2));
		if(name1.equals(name2)) {
			System.out.println("문자열이 같아요");
		}
		else {
			System.out.println("문자열이 달라요");
		}

		System.out.println(name1);////주의
		System.out.println(name2);////주의
		if(name1==name2) {////주의
			System.out.println("문자열이 같아요");
		}
		else {
			System.out.println("문자열이 달라요");
		}
	}
}
