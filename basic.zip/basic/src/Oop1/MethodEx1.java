package Oop1;

public class MethodEx1 {

	public static void main(String[] args) {
		Calculator primAndSugar = new Calculator();
		
		primAndSugar.menu1();
		
		primAndSugar.menu2("2. 설탕만 있는 커피");

		String coffee= primAndSugar.menu3();
		System.out.println(coffee);
		
		coffee=primAndSugar.menu4("4. 설탕");
		System.out.println(coffee);
	}

}
