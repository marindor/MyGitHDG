package Oop1;
public class BattleShip1 {
	int crewman;
	void sail() {
		System.out.println("항해하다");
	}
}
