package Oop1;

public class Animal {
	String name;
	int age;
	String race;
	String sound;
	int weight;
	int checkup;
	boolean wing;
	
	void speak() {
		System.out.println( sound + "~~");
	}
	void bePainful() {
		System.out.println( "건강이 안좋다.");
	}
	void hide() {
		System.out.println( "숨었다.");
	}
	void fly(){
		System.out.println( "날 수 있다.");
	}
	void run() {
		System.out.println("사라졌다.");
	}
}
