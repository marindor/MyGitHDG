package Oop1;

public class CalcTest {

	public static void main(String[] args) {
		Calc calc = new Calc();
		int result = calc.add(1, 2);
		System.out.println(result);

		result = calc.sub(1, 2);
		System.out.println(result);

		result = calc.mul(1, 2);
		System.out.println(result);
		
		double result1 = calc.div(1, 2);
		System.out.println(result1);
	}
}
