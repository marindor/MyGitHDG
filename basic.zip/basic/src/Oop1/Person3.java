package Oop1;

public class Person3 {
	
	String name;
	int age;
	
	Person3(){
		
	}
	
	Person3(String name){
		this.name=name;
	}

}
