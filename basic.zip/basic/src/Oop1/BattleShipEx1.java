package Oop1;
public class BattleShipEx1 {
	public static void main(String[] args) {
		BattleShip1 battleship = new BattleShip1();
		battleship.crewman =10;
		System.out.println("승무원 수는 " + battleship.crewman + "명 입니다.");
		battleship.sail();
	}
}
