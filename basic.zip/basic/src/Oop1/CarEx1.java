package Oop1;

public class CarEx1 {
	public static void main(String[] args) {

		Car1 Ev = new Car1();
		Ev.wheel=4;
		System.out.println(Ev.wheel);
		Ev.roll();
	}
}

