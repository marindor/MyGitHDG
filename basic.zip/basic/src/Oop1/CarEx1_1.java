package Oop1;

public class CarEx1_1 {
	public static void main(String[] args) {
		
		Car1_1 Ev = new Car1_1();
		Ev.wheel=5;
		System.out.println(Ev.wheel);
		Ev.roll();
		
	}

}
