package Oop1;

public class Calc {
	int add(int num1, int num2) {
		int result = num1 + num2;
		return result;
	}
	int sub(int num1, int num2) {
		int result = num1 - num2;
		return result;
	}	
	int mul(int num1, int num2) {
		int result = num1 * num2;
		return result;
	}
	double div(double num1, double num2) {
		double result = num1 / num2;
		return result;
	}		
}
