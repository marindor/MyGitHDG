package Oop1;

public class Person {
	int height;
	double weight;
	String name;
	char gender;
	boolean married;
	String hairColor; 
	String race;
	
	void sleep() {
		System.out.println("밤에 잠을 잔다.");		
	}
	void eat() {
		System.out.println("아침점심저녁을 먹는다.");
	}
	void speak() {
		System.out.println("말을 한다.");
	}
	void hear() {
		System.out.println("듣는다.");
	}
	void run() {
		System.out.println("달린다.");
	}
	void walk() {
		System.out.println("걷는다.");
	}
}
