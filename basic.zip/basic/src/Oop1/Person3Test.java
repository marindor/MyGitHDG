package Oop1;

public class Person3Test {
	public static void main(String[] args) {
		Person3 person3 = new Person3("홍길동");
		System.out.println(person3.name);
		
		Person3 person5 = new Person3("박달재");
		Person3 person6 = new Person3("김선달");
		Person3 person7 = new Person3("허준");
	}
	
}
