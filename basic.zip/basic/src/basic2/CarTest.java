package basic2;

public class CarTest {
	public static void main(String[] args) {
		Car cartest = new Car();
		cartest.move1();
		System.out.println(cartest.move2());
		cartest.move3("아이");
		System.out.println(cartest.move4("주유소"));
	}
}
