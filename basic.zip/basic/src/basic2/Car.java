package basic2;

public class Car {
	//필생매
	//필(속성 담당)
	String color;
	//생(초기화 담당
	Car(){
	}
	//매(함수 담당)
	void move1() {
		System.out.println("차가 달린다.");
	}
	String move2() {
		return "차가 멈췄다.";
	}
	void move3(String who) {
		System.out.println(who+"와 차사고가 났다.");
	}
	String move4(String where) {
		return where+"에서 차를 충전했다.";
	}
}
