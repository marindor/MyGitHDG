package basic2;

public class Student1Test {
	public static void main(String[] args) {
		Student1 student1 = new Student1();
		
		student1.setStudentName("이지원");
		System.out.println(student1.serialNumber);
		System.out.println(student1.StudentId);
		
		Student1 student2 = new Student1();
		System.out.println(student2.serialNumber);
		System.out.println(student2.StudentId);		
	}
}
