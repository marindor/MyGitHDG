package basic2;

public class Student {
	//필생매
	//필
	static int serialNumber=1001;//학번
	int studentID;//학생ID
	String studentName;//학생성명
	
	//생
	public Student() {
	}
	
	//매
	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	

	
}
