package basic2;

public class Student1 {
	//필생매
	//필
		static int serialNumber=1001;
		int StudentId;
		String studentName;
	//생
		public Student1() {
			serialNumber++;
			StudentId = serialNumber;
		}
		
	//매
		public String getStudentName() {
			return studentName;
		}
		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}
}
