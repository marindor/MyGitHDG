package generic;

public class MainTest {

	public static void main(String[] args) {
		GenericBasic<AAA> powerPrinter = new GenericBasic<AAA>();
		
		powerPrinter.getMaterial();
		powerPrinter.setMaterial("okay~!");
		
	}
}
