package generic;

public class AAA extends Material{
	@Override
	public void doPrinting() {
		System.out.println("doPrinting Override");
	}
}
