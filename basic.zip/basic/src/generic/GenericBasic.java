package generic;

public class GenericBasic<T extends Material> { ///Material을 T로 줄여쓰겠다.
//public class GenericBasic<T super AAA> { //super는 하위 타입을 쓸 것 (나중에 배우자)
	private T material;
	
	public T getMaterial() {
		return material;
	}
	
	public void setMaterial(T material) {
		this.material = material;
	}
	
	@Override
	public String toString() {
		return material.toString();
	}
	
	public void doPrinting() {
		System.out.println("aa");
	}
}
