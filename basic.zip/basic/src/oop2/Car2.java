package oop2;
public class Car2 {
	String color;
	
	void roll() {
		System.out.println("달린다");
	}
	
	Car2(){
		
	}

	
}
