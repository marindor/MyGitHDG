package oop2;

public class Car2Test {
	public static void main(String[] args) {
		Car2 car = new Car2();
		car.color = "yellow";
		System.out.println("자동차 색은 "+car.color +"입니다.");
		
	}

}
