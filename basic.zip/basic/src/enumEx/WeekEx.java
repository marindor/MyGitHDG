package enumEx;

import java.util.Calendar;

public class WeekEx {
	public static void main(String[] args) {
		Week today = null;
		Calendar cal = Calendar.getInstance();
		int week = cal.get(Calendar.DAY_OF_WEEK);
		System.out.println(week);
		//sunday가 1
		//friday가 6
		//language들은 요일을 0~6으로 표현한다. 엑셀도 그렇다.
		
		switch(week) {
		case 1:
			today = Week.SUNDAY;
			break;
		case 2:
			today = Week.MONDAY;			
			break;
		case 3:
			today = Week.TUESDAY;
			break;
		case 4:
			today = Week.THURSDAY;
			break;
		case 5:
			today = Week.FRIDAY;
			break;
		case 6:
			today = Week.SATURDAY;
			break;
		default:
			break;			
		}
		
		System.out.println("오늘은 "+today+"입니다");
		
	}
}
