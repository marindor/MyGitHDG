package pdfExam;

public class StringArray206pTest {
	public static void main(String[] args) {
		
		//230p Q2
		System.out.println("Q2");
		char alphabets[] = new char[26];
		char ch='A';
		
		for(int i=0; i<alphabets.length;i++) {
			alphabets[i]=ch; //대문자
			alphabets[i]+=32; //소문자
			ch++;
		}		
		
		for(int i=0;i<alphabets.length;i++) {
			System.out.println(alphabets[i]+","+(int)alphabets[i]);
		}
		System.out.println("===================");
		//Q3
		System.out.println("Q3");
		int arr[] = new int[5];
		int j=0;
		for(int i=1;i<=10;i++) {
			if(i%2==0) {
				arr[j]=i;
				System.out.print(arr[j]+" ");				
				j++;

				}
		}
		int total=0;
		for(int i=0;i<arr.length;i++) {
			total+=arr[i];
		}
		System.out.println("총합 : "+total);
		System.out.println("===================");
		
		//Q4
		
		
		
		
	}
}
