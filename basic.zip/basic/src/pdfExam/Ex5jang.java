package pdfExam;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

public class Ex5jang {
	public static void main(String[] args) {
		//5-1
		System.out.println();
		System.out.println();
		System.out.println("5-1번 : 배열 선언 오류 판단");		
		//int[] arr[]; //X new 생성자 없음
		//int[] arr = {1,2,3,}; //X 콤마 잘못됨
		//int[] arr = new int[5]; //OK
		//int[] arr = new int[5]{1,2,3,4,5};//X 초기화까지 한번에 안됨
		//int arr[5];//X new 생성자 없음
		//int[] arr[] = new int[3][];//x 크기지정 안함
		
		//5-2
		System.out.println();
		System.out.println();
		System.out.println("5-2번 : 배열의 길이");		
		int arr[][]= {
				{5,5,5,5,5},
				{10,10,10},
				{20,20,20,20},
				{30,30}
		};
		System.out.println("5-2 : 4번째 길이 : "+arr[3].length);
		
		
		//5-3
		System.out.println();
		System.out.println();
		System.out.println("5-3번 : 배열 내부 총합");				
		
		int[] arr3 = {10, 20, 30, 40, 50};
		int sum = 0;
		for(int i=0;i<arr3.length;i++) {
			sum+=arr3[i];
		}
		System.out.println("sum="+sum);
		

		//5-4
		System.out.println();
		System.out.println();
		System.out.println("5-4번 : 배열 내부 총합과 평균");				
		int[][] arr4 = {
				{ 5, 5, 5, 5, 5},
				{10,10,10,10,10},
				{20,20,20,20,20},
				{30,30,30,30,30}
				};
				int total = 0;
				float average = 0;
					for(int i=0;i<arr4.length;i++) {
						for(int j=0;j<arr4[i].length;j++) {
							total += arr4[i][j];
						}
						average += arr4[i].length;
				}
				average =  total/average;
				System.out.println("total="+total);
				System.out.println("average="+average);
				
				
				//5-5
				System.out.println();
				System.out.println();
				System.out.println("5-5번 : 중복하지 않는 수, 선생님 말씀으로 pass!");					
				

				//5-6
				System.out.println();
				System.out.println();
				System.out.println("5-6번 : 거스름돈 문제");									
				// . 큰 금액의 동전을 우선적으로 거슬러 줘야한다
				int[] coinUnit = {500, 100, 50, 10};
				int money = 2680;
				int temp = money;
				int remain = 0;
				System.out.println("money="+money);
				for(int i=0;i<coinUnit.length;i++) {
					System.out.println(coinUnit[i]+"원은 "+temp/coinUnit[i]+"개");
					temp = temp%coinUnit[i];
				}
				//5-7
				System.out.println();
				System.out.println();
				System.out.println("5-7번 : 5-6의 조건적 거스름돈");	
//				if(args.length!=1) {
//					System.out.println("USAGE: java Exercise5_7 3120");//매개변수 입력하는 곳
//					System.exit(0);
//				}
				// . . 문자열을 숫자로 변환한다 입력한 값이 숫자가 아닐 경우 예외가 발생한다
//				int money7= Integer.parseInt(args[0]);
				int money7= 2320;
				System.out.println("money="+money7);
				int coinUnit7[] = {500, 100, 50, 10 }; // 동전의 단위
				int coin[] = {5, 5, 5, 5}; // 단위별 동전의 개수
				for(int i=0;i<coinUnit7.length;i++) {
					System.out.print("잔액 : "+money7+"원 : ");
					int coinNum = 0;
					coinNum = money7/coinUnit7[i];
					
					if((coin[i]- coinNum)>0) {
						coin[i] = coin[i]- coinNum;
					}
					else {
						coinNum =5;
						coin[i] = 0;
					}
					System.out.println(coinUnit7[i]+"원 : "+coinNum+"개 사용"); 
					money7 -= (coinUnit7[i]*coinNum);
				}
				if(money7 > 0) {
					System.out.println("거스름돈이 부족합니다"); 
					System.exit(0); // . 프로그램을 종료한다
				}
				System.out.println("= 남은 동전의 개수 ="); 
				for(int i=0;i<coinUnit7.length;i++) {
					System.out.println(coinUnit7[i]+"원 :"+coin[i]); 
				}		
				
				
				//5-8 배열읽고 인덱스 숫자만큼 별표찍기
				System.out.println();
				System.out.println();
				System.out.println("5-8번 : 숫자 배열순회 후 존재하는 숫자만큼 *찍기");
				
				int answer[] = { 1,4,4,3,1,4,4,2,1,3,2 };
				int counter[] = new int[4];
				
				Arrays.sort(answer);
				int index=0;
				for(int i=0; i<answer.length;i++) {
					counter[answer[i]-1]++;
//					int k=1;
//					
//					if(answer[i]==0) {
//						continue;
//					}
//					else {
//						for(int j=i+1;j<answer.length;j++) {
//							if(answer[i]==answer[j]) {
//								answer[j]=0;
//								k++;
//							}
//						}
//						System.out.println("number:"+answer[i]+" : index: "+index+" : count: "+k);
//						counter[index]=k;
//						index++;						
//					}
				}
				System.out.println("================================");
				for(int i=0; i < counter.length;i++) {
					System.out.print(counter[i]);
					for(int j=0;j<counter[i];j++) {
						System.out.print("*");	
					}
					System.out.println();
				}
				
				
				//5-9. 배열 시계방향90도 회전 : 선생님 지시로 pass!
				
				//5-10. 암호화 프로그램
				System.out.println();
				System.out.println();
				System.out.println("5-10번 : 암호화 프로그램 완성");				
				char abcCode[] =
					{ '`','~','!','@','#','$','%','^','&','*',
					'(',')','-','_','+','=','|','[',']','{',
					'}',';',':',',','.','/'};
					// 0 1 2 3 4 5 6 7 8 9
					char[] numCode = {'q','w','e','r','t','y','u','i','o','p'};
					String src = "abc123";
					String result = "";
					// src charAt() result 문자열 의 문자를 으로 하나씩 읽어서 변환 후 에 저장
					for(int i=0; i < src.length();i++) {
						char ch = src.charAt(i);
						if(ch>47 && ch<58) {
							int num = ch - 48;
							result += numCode[num]; 
						}
						else {
							int num = ch - 'a';
							result += abcCode[num];
						}
					}
					System.out.println("src:"+src);
					System.out.println("result:"+result);
					
					//5-11.12.13 선생님 지시로 모두 pass
					
					
					
				
					
	}
}
