package pdfExam;

class MyDog {
	String name;
	String type;
	
	public MyDog(String name1, String name2) {
		System.out.println(name2+name1);
	}
	
}

public class Q4_386p{
	public static void main(String[] args) {
		MyDog dog = new MyDog("멍멍이","진돗개");
		System.out.println(dog);
	}
}
