package pdfExam;

public class Q7_346p {
	public static void main(String[] args) {
		System.out.println("정렬 방식을 선택하세요.");
		System.out.println("B : BubbleSort");
		System.out.println("H : HeapSort");
		System.out.println("Q : QuickSort");
		
		int ch = System.in.read();
		Sort sort = null;
		
		if(ch == 'B' || ch =='b') {
			sort = new BubbleSort();
		}
		else if(ch == 'H' || ch =='h') {
			sort = new HeapSort();
		}
	}
}
