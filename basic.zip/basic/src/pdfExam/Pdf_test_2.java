package pdfExam;

public class Pdf_test_2 {
	static byte var; //static 고정한다는 의미인데 여기서는 클래스 안에서 변수를 고정한다. 클래스 변수
	 //클래스 변수는 기본값이 있는데 0이다.
	static short var2;
	static int var3;
	static long var4;	//기본값 0L
	static float var5;	//기본값 0.0f
	static double var6;

	static char var7;
	static boolean var8;
	static String str;	//기본형을 제외한 나머지(참조형)의 기본값은 null이다.
	
	public static void main(String[] args) {
		//모든 데이터 타입의 기본값은 0이다.
		System.out.println(	var);
		System.out.println(var2);
		System.out.println(var3);
		System.out.println(var4);
		System.out.println(var5);
		System.out.println(var6);
		System.out.print(var7);
		System.out.println("#");
		System.out.println(var8);
		System.out.print('\u0000');
		System.out.println("#");
		System.out.println(str);
	}
}