package pdfExam;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

class SutdaCard {//6-1.
	int cardNum;
	boolean isKwang;
	
	public SutdaCard() {//6-2.
		this.cardNum = 1;
		this.isKwang = true;		

	}
	public SutdaCard(int cardNum, boolean isKwang) {//6-2.
		this.cardNum = cardNum;
		this.isKwang = isKwang;
	}
	
	String info() {//6-2.
		if(isKwang) {
			return cardNum+"K";
		}
		return cardNum+"";
	}
	
	String info(int a) {
		return "";
	}
	
	int info(int b, int c) {
		return 5;
	}
}


class Student{//6-3
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;
	
	int getTotal() {
		return kor + eng + math;
	}
	float getAverage() {
		return (getTotal()/3f);
	}
}

class MyPoint {
	int x;
	int y;
	MyPoint(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	double getDistance(int x1, int y1) { //6-7
		return Math.sqrt((x-x1)*(x-x1)+(y-y1)*(y-y1));
	}
}

public class Ex6jang {
	
	static double getDistance(int x, int y, int x1, int y1) { //6-6
		return Math.sqrt((x-x1)*(x-x1)+(y-y1)*(y-y1));
	}
	
	
	public static void main(String[] args) {
		
		//6-1. 멤버변수를 갖는 SutdaCard 클래스 선언
		System.out.println();
		System.out.println();
		System.out.println("6-1번 : 멤버변수를 갖는 클래스 선언");
		System.out.println("위에 StudentCard 클래스 선언했음");
		
		//6-2. SutdaCard에 2개 생성자 , info()메서드 추가 실행
		System.out.println();
		System.out.println();
		System.out.println("6-2번 : 생성자 2개 추가 및 메서드 추가");
		System.out.println("위에 SutdaCard 클래스 선언했음");		
		SutdaCard card1 = new SutdaCard(3, false);
		SutdaCard card2 = new SutdaCard();
		System.out.println(card1.info());
		System.out.println(card2.info());
		
		//6-3. Student class 정의
		System.out.println();
		System.out.println();
		System.out.println("6-3번 : 위에 Student 클래스 선언했음");
		
		//6-4. Student class 메서드 추가
		System.out.println();
		System.out.println();
		System.out.println("6-4번 : Student class 메서드 추가");
		
		
		//6-5. main 구현
		System.out.println();
		System.out.println();
		System.out.println("6-5번 : Student class main 구현");		
		Student s = new Student();
		s.name = "홍길동"; 
		s.ban = 1;
		s.no = 1;
		s.kor = 100;
		s.eng = 60;
		s.math = 76;
		System.out.println("이름 :"+s.name); 
		System.out.println("총점 :"+s.getTotal()); 
		System.out.println("평균 :"+String.format("%.1f",s.getAverage())); 
		
					
		//6-6. 두 점 사이의 거리 구하기
		System.out.println();
		System.out.println();
		System.out.println("6-6번 : 두 점 사이의 거리");			
		System.out.println(getDistance(1,1,2,2));
		
		//6-7. 6-6과 연계, 내 지점과의 거리 구하기
		System.out.println();
		System.out.println();
		System.out.println("6-7번 : 내 지점과의 거리 구하기");		
		
		MyPoint p = new MyPoint(1,1);
		// p (2,2) . 와 의 거리를 구한다
		System.out.println(p.getDistance(2,2));

		
		//6-8. 클래스 용어 정리
		System.out.println();
		System.out.println();
		System.out.println("6-8번 : class 용어 정리");				
//		class PlayingCard {
//			int kind;
//			int num;
//			static int width;
//			static int height;
//				PlayingCard(int k, int n) {
//				kind = k;
//				num = n;
//			}
//			public static void main(String args[]) {
//				PlayingCard card = new PlayingCard(1,1);
//			}
//		}
		System.out.println("클래스 변수는 최초 한번만 메모리에 올릴 static 변수는 그것은 static width, static height");
		System.out.println("인스턴스변수는 인스턴스 에서 쓸 변수 kind,num");
		System.out.println("지역변수는 k,n,card");

		
		//6-9. 병사 게임 정의 문제
		System.out.println();
		System.out.println();
		System.out.println("6-9번 : 병사 게임 정의 문제");
//		class Marine {
//			int x=0, y=0; // Marine (x,y) 의 위치좌표
//			int hp = 60; // 현재 체력
//			int weapon = 6; // 공격력
//			int armor = 0; // 방어력
//			void weaponUp() {
//			weapon++;
//			}
//			void armorUp() {
//			armor++;
//			}
//			void move(int x, int y) {
//			this.x = x;
//			this.y = y;
//			}
//		}
		System.out.println("weapon과 armor는 static을 붙여야 한다.");
		System.out.println("모든 병사의 공격과 방어력이 같아야 한다고 하였으므로");
		System.out.println("이 클래스로 만든 객체는 메모리에 weapon과 armor를 객체 만들때마다 메모리를 할당하는게 아니다.");
		System.out.println("static을 써서 모든 인스턴스들이 이 한 메모리와 참고하도록 한다.");
		System.out.println("static void weaponUp()");
		System.out.println("static void armorUp()");
		
		//6-10. 4지선 택일 문제
		System.out.println();
		System.out.println();
		System.out.println("6-10~17번 : 4지선 택일 문제");
		System.out.println("6-10번");
//		다음 중 생성자에 대한 설명으로 옳지 않은 것은 모두 고르시오 ?
//		a. . 모든 생성자의 이름은 클래스의 이름과 동일해야한다
		System.out.println("b. . 생성자는 객체를 생성하기 위한 것이다->초기화 하기 위함이다");
//		c. . 클래스에는 생성자가 반드시 하나 이상 있어야 한다
//		d. . 생성자가 없는 클래스는 컴파일러가 기본 생성자를 추가한다
		System.out.println("e.생성자는 오버로딩 할 수 없다->있다!!!");
		
		//6-11. 4지선 택일 문제
		System.out.println("6-11번");
//		this에 대해 틀리 것은?
//		a. . 객체 자신을 가리키는 참조변수이다
		System.out.println("b. . 클래스 내에서라면 어디서든 사용할 수 있다 -> static 변수나 static method()는 this를 못쓴다.")
//		c. . 지역변수와 인스턴스변수를 구별할 때 사용한다
		System.out.println("d. . 클래스 메서드 내에서는 사용할 수 없다.맞음. 왜냐면 static 메서드이기 때문이다.");
		
		//6-12. 4지선 택일 문제
		System.out.println("6-12번");
//		오버로딩이 성립하기 위한 조건이 아닌 것은?
//		a. . 메서드의 이름이 같아야 한다
//		b. . 매개변수의 개수나 타입이 달라야 한다
		System.out.println("c. . 리턴타입이 달라야 한다->상관없다.");
		System.out.println("d. . 매개변수의 이름이 달라야 한다. -> 상관없다.");
		
		//6-13. 4지선 택일 문제
		System.out.println("6-13번");
//		아래 메서드를 올바르게 오버로딩 한 것은 모두 고르시오 add ?
//		long add(int a, int b) { return a+b;}
//		a. long add(int x, int y) { return x+y;}
		System.out.println("b. long add(long a, long b) { return a+b}");
		System.out.println("c. int add(byte a, byte b) { return a+b;}");
		System.out.println("d. int add(long a, int b) { return (int)(a+b);}");
		
		//6-14. 4지선 택일 문제
		System.out.println("6-14번");
		//초기화에 대한 설명으로 옳지 않은 것은 모두 고르시오 ?
		a. 멤버변수는 자동 초기화되므로 초기화하지 않고도 값을 참조할 수 있다. -> 맞다.
		b. 지역변수는 사용하기 전에 반드시 초기화해야 한다. -> 맞다.
		c. 초기화 블럭보다 생성자가 먼저 수행된다. -> 아니다. 초기화 static 블럭을 먼저 수행한다.
		d. 명시적 초기화를 제일 우선적으로 고려해야 한다. -> 맞다. 객체 생성 전에 먼저 실행하기 때문이다.
		e. 클래스변수보다 인스턴스변수가 먼저 초기화된다.-> 아니다. static즉, 클래스변수가 먼저 초기화
		
		[6-15] 다음중 인스턴스변수의 초기화 순서가 올바른 것은?
		a. 기본값 - 명시적초기화 - 초기화블럭 - 생성자  (정답) 기본값이란, 명시적 초기화 즉, class 내에서 int speed=80; 이런거다.
		b. 기본값 - 명시적초기화 - 생성자 - 초기화블럭
		c. 기본값 - 초기화블럭 - 명시적초기화 - 생성자
		d. 기본값 - 초기화블럭 - 생성자 - 명시적초기화
		
		
		[6-16] 다음 중 지역변수에 대한 설명으로 옳지 않은 것은 모두 고르시오 ? ( )
		a. 자동 초기화되므로 별도의 초기화가 필요없다 -> 아니다. 지역변수는 수동으로 초기화해야함
		b. 지역변수가 선언된 메서드가 종료되면 지역변수도 함께 소멸된다 -> 맞다.
		c. 매서드의 매개변수로 선언된 변수도 지역변수이다 -> 맞다.
		d. 클래스변수나 인스턴스변수보다 메모리 부담이 적다 -> 맞다. 왜냐면 지역변수는 용도가 끝나면 소멸하기 때문이다. 
		e. 힙 영역에 생성되며 가비지 컬렉터에 의해 소멸된다 -> 아니다. 지역변수는 무조건 stack에 생긴다. 힙에는 인스턴스 변수가 생긴다.
		
		
		[6-17] 호출스택이 다음과 같은 상황일 때 옳지 않은 설명은 모두 고르시오 ? ( )
				println
				method1
				method2
				main
				
		a. 제일 먼저 호출스택에 저장된 것은 main 메서드이다 -> 맞다.
		b. println 메서드를 제외한 나머지 메서드들은 모두 종료된 상태이다 -> 아니다. 대기상태이다. 메모리 올라가있다.
		c. method2 메서드를 호출한 것은 main 메서드이다 -> 맞다. 
		d. println 메서드가 종료되면 method1 메서드가 수행을 재개한다 -> 맞다.
		e. main-method2-method1-println . 의 순서로 호출되었다 -> 맞다.
		f. 현재 실행중인 메서드는 println이다. -> 맞다.
		
		
		[6-18] 다음의 코드를 컴파일하면 에러가 발생한다 컴파일 에러가 발생하는 라인과 그 이유를 설명하시오.
		다음 시간에~~
					
	}
}
