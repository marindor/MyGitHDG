package pdfExam;

import java.util.ArrayList;


public class Dog {
	//필생매
	//필
	private String name;
	private String type;
	
	//생
	public Dog(){
	}
	public Dog(String name,String type) {
		this.name=name;
		this.type=type;
	}
	
	//매
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type=type;
	}
	public String showDogInfo() {
		return name+","+type;
	}
	
	public static void main(String[] args) {
		//230page Q4
		String hotdog[] = new String[5];
		for(int i=0;i<hotdog.length;i++) {
			hotdog[i]="hotdog"+i+","+"hottype"+i;
		}
		for(String count:hotdog) {
			System.out.println(count);
		}
		
		//230page Q5
		Dog dog[] = new Dog[5];
		ArrayList dogList = new ArrayList();//--------------
		for(int i=0;i<dog.length;i++) {
			dogList.add(new Dog("dog"+i,"type"+i));//--------------------
		}
		for(int i=0;i<dog.length;i++) {
			Dog dogPrint =(Dog)dogList.get(i);//---------------
			System.out.println(dogPrint.name+":"+dogPrint.type);
			
		}
		
		
	}
	
}
