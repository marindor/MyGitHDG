package pdfExam;

import java.util.Scanner;

public class Ex4jang {
	public static void main(String[] args) {
	//4-1. 다음의 문장들을 조건식으로 표현하라.
		System.out.println("4-1번");
	//1. int변수 x가 10보다 크고 20보다 작을 때 true인 조건식
		int x=15;
		System.out.println(x>10&&x<20);
	//2. char형 변수 ch가 공백이나 탭이 아닐 때 인 true인 조건식
		char ch='\u0000';
		System.out.println(!(ch==0||ch==9));
	//3. char형 가 ch변수  ‘x' 또는 ’X'일 때  true인 조건식
		ch='x';
		System.out.println(ch=='x'||ch=='X');
	//4. char ch 형 변수 가 숫자(‘0’~‘9’)일 때 인 조건식 true
		ch='6';
		System.out.println(ch>=48&&ch<=57); 
	//5. char형 ch변수 가 영문자 일 때(대문자 또는 소문자) true인 조건식
		ch='+';
		System.out.println((ch>=65&&ch<=90)||(ch>=97&&ch<=122));
	//6. int형 year변수가 400으로 나눠떨어지거나 또는 4로 나눠떨어지고 100으로 나눠떨어지지 않을 때 true인 조건식
		int year = 403;
		System.out.println(year%400==0 || (year%4==0)&&(year%100!=100));
	//7. boolean형 변수 powerOn가 false일 때 true조건식
		boolean powerON = false;
		System.out.println(!powerON);
	//8. 문자열 참조변수 str이 “yes”일 때 true인 조건식
		String str = "no";
		System.out.println(str=="yes");
		
	//4-2. 
		System.out.println();
		int total=0;
		for(int i=1;i<=20;i++) {
			if(i%2==0 || i%3==0) {
				
			}
			else{
				total+=i;
			}
		}
		System.out.println("4-2 : "+total);
		System.out.println();
		
	//4-3.
		total=0;
		int total2=0;
		for(int i=1;i<=10;i++) {
//			System.out.print ("i->"+i+" : ");
				total+=i;
//				System.out.print(total+" ");				
				total2+=total;
//				System.out.println(total2);
		}
		System.out.println("4-3 : "+total2);
		
	//4-4.
		System.out.println();
		total=0;
		int plus=1;//while문 내 +1 증가변수
		int num=1;//합산할 가변 숫자
		int count=1;//부호 변경자
		total=0;//합계를 보는 변수
		while(total<100) {
			num=plus;
			num*=count;
			count*=(-1);
//			System.out.println("num="+num);
			total+=num;
//			System.out.println(total);

			plus++;

		}
		System.out.print("4-4: "+num+"까지 더하면 "+plus+"번째에서 ");
		System.out.println(total+"이 나온다.");

		//4-5
		
		System.out.println("4-5");
		count=0;
		while(count<=10) {
//			System.out.print("*");	
			count++;
			for(int i=0;i<count;i++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		
		//4-6
		System.out.println("4-6");
		for(int i=1;i<=6;i++) {
			for(int j=1;j<=6;j++) {
				if((i+j)==6) {
					System.out.print("["+i+","+j+"]");
				}
			}
		}

		
		//4-7
		System.out.println();
		System.out.println("4-7");
		double a= Math.round(Math.random()*6);
		int value = (int)a;
		System.out.println("value: "+value);
		
		
		
		//4-8
		System.out.println();
		System.out.println("4-8");
		
		total=0;
		for(int i=0;i<=10;i++) {
			for(int j=0;j<=10;j++) {
				total=2*i+4*j;
				if(total==10) {
					System.out.println("("+i+","+j+")");
				}
			}
		}
		System.out.println();
		
		//4-9
		str="12345";
		int sum=0;
		String k;
		for(int i=0;i<str.length();i++) {
			k=str;
			k=k.substring(str.length()-i-1,str.length()-i);
			num=Integer.parseInt(k);
			sum+=num;
		}
		System.out.print("4-9. "+sum);
		System.out.println();
		
		//4-10
		num=12345;
		sum=0;
		int mok=0;
		int namoji=0;
		while(num%10!=0) {
			namoji =num%10;
			mok=num/10;
			sum+=namoji;
			num=mok;
		}
		System.out.print("4-10. ");
		System.out.println(sum);
		
		//4-11
		int aa=1;
		int bb=1;
		count=3;//몇번째 숫자인지 세는 변수
		int c=aa+bb; //최초 c는 3번째 숫자이다.
		
		while(count<=10) {
			c=aa+bb;
			aa=bb;
			bb=c;
			count++;
		}
		System.out.println("4-11번 : "+c);
		
		System.out.println();
		
		//4-12
		System.out.println("4-12번 : 구구단");
		int sub1;
		int sub2=1;
		for(int i=2;i<=9;i++) {
			sub1=i;
			//flag 있어야 할듯!!!!!!!!!!
			for(int j=0;j<3;j++) {
				System.out.print(sub1+"*"+sub2+"="+(sub1*sub2)+"\t");
				sub1++;
			}
			System.out.println();
			if(i==4 || i==7) {
				System.out.println();
			}
		}
		
		//4-13 주어진 문자열 이 숫자인지를 판별
		System.out.println();
		System.out.println("4-13번 : 숫자문자판별");
        String value13 = "12x34";
        char ch13 = ' ';
        boolean isNumber = true;
        // charAt(int i) 반복문과 를 이용해서 문자열의 문자를
        // . 하나씩 읽어서 검사한다
        for(int i=0; i < value13.length() ;i++) {
        	ch13 = value13.charAt(i);//핵심
        	if(ch13>=48 && ch13<=57) {
        		isNumber = true;
        		System.out.println(ch13);
        	}
        	else {
        		isNumber = false;
        		System.out.println(ch13);
        		break;
        	}
        }
        if (isNumber) {
        	System.out.println(value13+"는 숫자입니다"); 
        } else {
        	System.out.println(value13+"는 숫자가 아닙니다"); 
        }


		//4-14 1~100사이 숫자 맞추기
		System.out.println();
		System.out.println("4-13번 : 1~100사이 숫자 맞추기");        
        
		// 1~100 사이의 임의의 값을 얻어서 answer에 저장한다
		Scanner s = new Scanner(System.in);
		System.out.print("1~100 사이 수 입력: ");
		int answer = 66;
//		int answer = (int)(Math.random()*100)+1;
		int input14 = 0; // 사용자입력을 저장할 공간
		int count14 = 0; // 시도횟수를 세기위한 변수
		// Scanner 화면으로 부터 사용자입력을 받기 위해서 클래스 사용
		do {
			count14++;
			System.out.print("1 100 : 과 사이의 값을 입력하세요"); 
			input14 = s.nextInt(); // input . 입력받은 값을 변수 에 저장한다
			if(input14<answer) {
				System.out.println("더 큰 수를 입력해라.");
			}
			else if(input14>answer) {
				System.out.println("더 작은 수를 입력해라.");
			}
			else {
				System.out.println("정답");
				System.out.print("시도 횟수는 ");
				System.out.print(count14);
				System.out.print("번");
				break;
			}
		} while(true); // 무한반복문    
		
		
		//4-15 회문수 판별
		System.out.println();
		System.out.println();
		System.out.println("4-15번 : palindrome 앞뒤가 똑같은 숫자. 회문수 판별 문제");

		int number = 12321;
		int tmp = number;
		int result =0; // number 변수 를 거꾸로 변환해서 담을 변수
		while(tmp !=0) {
			result = tmp%10+result;
			tmp/=10;
			if(tmp!=0) {
				result*=10;	
			}
			System.out.println(result);
		}
		if(number == result)
			System.out.println( number + "는 회문수 입니다");
		else
			System.out.println( number + "는 회문수가 아닙니다"); 
		
		
		
	}
}
