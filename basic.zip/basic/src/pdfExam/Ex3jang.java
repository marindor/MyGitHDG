package pdfExam;

public class Ex3jang {
	public static void main(String[] args) {
		//3-1
		System.out.println("3-1결과는");
		//3<<33 , 3을 즉 0011을 33번 옮겨라
		//int는 4byte 32bit
		//33bit 이동하라는 것은 1bit 이동하라는 것, 결과는 0110, 6이다.
		System.out.println(0110);
		
		//y>=5 는 y=5+5=10
		//x<0 는 2<2 그래서 false
		//x>2 는 2>2 그래서 false
		// 10 || false && false, 결과는 false(x=0, y=10)
		System.out.println(false);
		//y=y+10 -> y=20, y-x=20-0=0, 결과는 0
		//(x=0, y=20)
		System.out.println(0);
		//x+=2 -> x=x+2 -> x=0+2 =2
		//(x=2, y=20)
		System.out.println("x= "+2);
		//('A' <= c)==('A' <= 'A') == true
		//(c <='Z') == false
		//true && false == false
		System.out.println(false);
		//'C'-c == 'C'-'A' == 99-97 == 2
		System.out.println(2);
		//'5'-'0' == 35-30 == 5
		System.out.println(5);
		//c+1 == 'A'+1 == 97+1 = 98
		System.out.println(98);
		//++c == ++'A' == 97+1 = 98
		System.out.println(98);
		//c++ == 'A'++ == 97
	    //다음 명령줄부터 c==98=='B'
		System.out.println('B');		
		System.out.println("==============");
		
		//3-2
		int numOfApples = 123; // 사과의 개수
		int sizeOfBucket = 10; // ( ) 바구니의 크기 바구니에 담을 수 있는 사과의 개수
		int numOfBucket = (numOfApples/sizeOfBucket + (numOfApples%sizeOfBucket!=0?1:0)); // 모든 사과를 담는데 필요한 바구니의 수
		System.out.println("3-2 결과는 ");
		System.out.println("총 바구니 수 :"+numOfBucket);
		//13개의 바구니가 필요하다.
		System.out.println("==============");
		
		//3-3
		int num = 10;
		if(num>0) {System.out.println("3-3결과는 양수");}
		else if(num==0) {System.out.println("3-3결과는 0");}
		else {System.out.println("3-3결과는 음수");}
		System.out.println("==============");
		System.out.println( num>0 ? "양수" : (num<0 ? "음수" : "0") );//삼항연산자법, 한줄 요약
		
		//3-4
		int num34 = 456;
		int result=0;
		result= num34%100;
		if(result > 0) {
			result=num34/100;
			System.out.println("3-4 결과는 "+ result*100);
			}
		System.out.println("==============");
		
		//3-5
		int num35 = 333;
		int test_a35 = num35%10;
		int test_b35 = num35/10;
		int result35 = test_b35;
		if(test_a35>0) {
			result35 =  result35*10 +1;
			System.out.println("3-5 결과는 "+ result35);
		}
		System.out.println("==============");
		
		//3-6
		int num36 = 24;
		//num을 10의 배수로 만들기
		int num36a = num36/10*10;
		int num36b = num36%10;
		//가장 가깝고 큰 10의 배수 찾기
		if(num36b>0) {
			num36a+=10;
			System.out.println("3-6 결과는 "+num36a);
		}
		System.out.println("==============");
		
		//3-7
		int fahrenheit = 100;
		float test37a = 5/9f;
		float test37b = (float)fahrenheit-32;
		float celcius = test37a*test37b;
		celcius *= 10000;
		int celcius37 =(int)celcius; 
		celcius37 = celcius37/10;
		if(celcius37%10>0) {
			celcius37=celcius37/10;
			celcius37+=10;
		}
		celcius =  celcius37*0.01f;
		System.out.println("3-7 결과는");
		System.out.println("Fahrenheit:"+fahrenheit);
		System.out.println("Celcius:"+celcius);
		System.out.println("==============");
		
		//3-8
		byte a = 10;
		byte b = 20;
		int c = a + b;
		char ch = 'A';
		ch = (char)(ch + 2);
		float f = 3 / 2;
		long l = 3000 * 3000 * 3000;
		float f2 = 0.1f;
		double d = 0.1;
		boolean result38 = d==f2;
		System.out.println("3-8 결과는 ");
		System.out.println("c="+c);
		System.out.println("ch="+ch);
		System.out.println("f="+f);
		System.out.println("l="+l);
		System.out.println("result="+result38);
		System.out.println("==============");
		
		//3-9
		char ch39 = 'z';
		boolean b39 = false;
		if(ch39 > 64 && ch39 <91) {//대문자 아스키값
			b39 = true;
		}else if(ch39 > 96 && ch39 <12) {//소문자 아스키값
			b39 = true;
		}else if(ch39 > 47 && ch39 <58) {//0~9 아스키값
			b39 = true;
		}else {
			b39 = false;
		}
		System.out.println("3-9 결과는 "+b39);
		System.out.println("==============");
		//3-10
		char ch310 = 'A';
		char lowerCase = (ch310 > 64 && ch310 <91) ? (char)(ch310+32) : ch310;
		System.out.println("3-10 결과는 ");
		System.out.println("ch:"+ch310);
		System.out.println("ch to lowerCase:"+lowerCase);
		System.out.println("==============");
	}
}
