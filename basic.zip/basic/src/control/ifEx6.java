package control;

public class ifEx6 {
	public static void main(String[] args) {
		/////////////////////////
		if(true) {
			
		}
		/////////////////////////
		if(true) {
			
		}else {
			
		}
		
		/////////////////////////		
		if(false) {
			
		}else {
			
		}
		
		/////////////////////////
		if(false) {
			
		}
		else if(true) {
			
		}
		else if(true) {
			
		}
		else {
			
		}
	}
}
