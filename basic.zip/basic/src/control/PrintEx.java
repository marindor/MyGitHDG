package control;

public class PrintEx {
	public static void main(String[] args) {
		System.out.println("hi");//hi 찍고 "줄바꿈하고 커서 대기"
		System.out.println();//또 "줄바꿈하고 대기"
		System.out.println("nice");//nice 쓰고 "줄바꿈하기 커서 대기"
		
		System.out.print("how are");//바로 how are 씀. 줄바꿈x
		System.out.print("you?");//이어서 you? 씀, 줄바꿈 x
		
		System.out.print("i'm"); //이어서 i'm 씀, 줄바꿈 x
		System.out.println();//줄바꿈하고 커서 대기
		System.out.println("fine");//fine 쓰고 줄바꿈하고 대기
		
		
		int i=1;
		int j=1;
		System.out.println(i + "," + j);
		
		
	}

}
