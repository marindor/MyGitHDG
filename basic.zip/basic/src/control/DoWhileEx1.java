package control;

public class DoWhileEx1 {
	public static void main(String[] args) {
		
		System.out.println("while으로 1~10 더하기");
		int i=0;
		int total=0;
		while(i<10) {
			i++;
			total+=i;
		}
		System.out.println(total);
		
		System.out.println("do-while으로 1~10 더하기");
		i=0;
		total=0;
		do {
			i++;
			total+=i;
		}while(i<10);
		System.out.println(total);
	}
}
