package control;

public class IfEx1 {
	public static void main(String[] args) {
		if(true) {
			System.out.println("hi");
		}
	}
}
