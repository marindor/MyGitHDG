package control;

public class ForEx1 {
	public static void main(String[] args) {
		
		int sum = 0;
		for(int i=1;i<=100;i++) {
			System.out.println(i);
			sum+=i;
		}
		System.out.println(sum);
		
		System.out.println("test(2%2==0)는 "+(2%2==0));
		int jjacksum=0;
		for(int i=0;i<=100;i++) {
			if(i%2==0) {
				jjacksum+=i;
			}
		}
		System.out.println(jjacksum);
	}
}

