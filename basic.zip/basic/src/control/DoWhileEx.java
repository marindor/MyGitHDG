package control;

public class DoWhileEx {
	public static void main(String[] args) {

//		int i=0;
//		do {
//			System.out.println(i+". 일단 하기");
//			i++;
//			}while(i<10);
		
		int i=0;
		do {
			i++;
			System.out.println(i);
		}while(i<10);
	}

}
