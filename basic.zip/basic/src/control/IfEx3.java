package control;

public class IfEx3 {
	public static void main(String[] args) {
		int age = 8;
		if (age >= 8) {
			System.out.println("학교에 갈 수 있다.");
		}
	}
}
