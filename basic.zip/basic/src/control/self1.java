package control;

public class self1 {
	public static void main(String[] args) {
		if (true) {
			System.out.println("self1");
		}

		int score = 95;
		if (score >= 90) {
			System.out.println("합격");
		} else {
			System.out.println("불합격");
		}

		int scorex = 65;
		if (scorex >= 90) {
			System.out.println("A");
		} else if (scorex >= 80) {
			System.out.println("B");
		} else if (scorex >= 70) {
			System.out.println("C");
		} else {
			System.out.println("D");
		}

		int rpm = -1000;
		if (rpm < 0) {
			System.out.println("자동차 고장남");
		} else if (rpm <= 1000) {
			System.out.println("기어 저단");
		} else if (rpm <= 2000) {
			System.out.println("기어 중저단");
		} else if (rpm <= 3000) {
			System.out.println("기어 중단");
		} else {
			System.out.println("기어 고단");
		}

	}
}
