package control;

public class SwitchCaseEx1 {
	public static void main(String[] args) {
		System.out.println("---총 쏘기 게임 첫번째 입니다.---");
		int shot1 = (int)(Math.random()*10+1);
		switch(shot1) {
		case 10:
			System.out.println("명중! 10점입니다!");
			break;
		case 9:
			System.out.println("명중! 9점입니다!");
			break;
		case 8:
			System.out.println("명중! 8점입니다!");
			break;
		case 7:
			System.out.println("빗맞음! 7점입니다.");
			break;
		case 6:
			System.out.println("빗맞음! 6점입니다.");
			break;
		default:
			System.out.println("탈락입니다! 다음 기회에!");
			break;
		}
		
		System.out.println("---총 쏘기 게임 두번째 입니다.---");
		int shot2 = (int)(Math.random()*10+1);
		switch(shot2) {
		case 10:
			System.out.println("명중! 10점입니다!");
			break;
		case 9:
			System.out.println("명중! 9점입니다!");
			break;
		case 8:
			System.out.println("명중! 8점입니다!");
			break;
		case 7:
			System.out.println("빗맞음! 7점입니다.");
			break;
		case 6:
			System.out.println("빗맞음! 6점입니다.");
			break;
		default:
			System.out.println("탈락입니다! 다음 기회에!");
			break;
		}
		
		int shot = shot1 + shot2;
		System.out.println("총 점수는");
		System.out.println(shot);
		System.out.println("입니다.");
				
		if(shot >= 15) {
			System.out.println("15점 이상입니다. 합격!");
		} else {
			System.out.println("15점 미만입니다. 불합격!");
		}
	}
}
