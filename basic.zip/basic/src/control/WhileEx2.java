package control;

public class WhileEx2 {
	public static void main(String[] args) {

		int i=1;
		int total=0;
		int total_j=0;
		int total_h=0;
		while(i<=100) {
			total+=i;
			
			if(i%2==0) { //짝수일 때
				total_j+=i;
			}
			//볼일 다 봤고!
			else {	//홀 수일 때
				total_h+=i;
			}
			i++; //증가 ㄱㄱ
		}
		System.out.println(total);
		System.out.println(total_j);
		System.out.println(total_h);
	}
}
