package control;

public class IfEx2 {
	public static void main(String[] args) {
		int weight = 97;
		if (weight >= 90) {
			System.out.println("당신은 찐비만이다.");
		} else {
			System.out.println("당신은 정상이거나 마르거나 비만초기이다.");
		}
	}
}
