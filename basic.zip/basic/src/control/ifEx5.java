package control;

public class ifEx5 {
	public static void main(String[] args) {
		//1
		if(true) {
			
		}
		//2-1
		if(true) {
			
		}else {
			
		}

		//2-2
		if(false) {
			
		}
		else{
			
		}
		
		//3
		if(false) {
			
		} else if(true){
			
		} else if(true){
			
		}else {
			
		}
	}
}
