package control;

public class WhileEx1 {
	public static void main(String[] args) {
		
		for(int i=1;i<=10;i++) {
			System.out.print(i);
		}
		
		System.out.println();
		
		int i=0;
		while(i<10) {
			i++;
			System.out.print(i);
		}
		
		System.out.println();
		switch(i) {
			case 10:
				System.out.println("i는" +i+"이다.");
				break;
			default:
				break;
		}
	}
}
