package ClassClass;

public class TypeEx {
	public static void main(String[] args) {
		int num=2; //객체 아님. 기본 타입 변수임
		String str1 = "hi";
		System.out.println(str1.getClass().getName());
		
		Car avante = new Car();
		avante.fuel = 80;
		avante.drvie("아반떼");
		Class classInfo = avante.getClass();
		System.out.println(classInfo); 
		
		System.out.println();
		System.out.println(classInfo.getName());//package.class 이름
		System.out.println(classInfo.getPackageName());//package 이름만
		System.out.println(classInfo.getSimpleName());//class 이름만
	}
}
