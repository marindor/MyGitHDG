package ClassClass;

public class Car {
	//필생매
	//필
	public int fuel;
	public String model;
	//생
	public Car() {
	}
	public Car(int a) {
	}
	public Car(String s, int k) {
	}
	//메
	public void drvie(String name) {
		System.out.println(name+" 주행 중 입니다.");
	}
	public void stop() {
		System.out.println("멈춰");
	}
}