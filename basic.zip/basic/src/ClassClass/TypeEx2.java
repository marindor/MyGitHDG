package ClassClass;

public class TypeEx2 {
	public static void main(String[] args) {
		//객체를 생성하기 전에 직접 Class 객체를 얻을 수도 있다.

		try {//에외가 발생할 것 같은 코드는 반드시 여기에 넣어라!!
			Class classInfo = Class.forName("ClassClass.Car");
			//클래스 전체 이름(패키지 포함)
			System.out.println(classInfo.getName());
		}catch(Exception e) {
			System.out.println("내가 표시하고 싶은 에러 메시지");
			e.printStackTrace(); //stack이 쌓이는 구조에서 꺼내기 & print하기
		}
	}
}
