package ClassClass;

public interface Action {
	//상추디정
	abstract void execute();

}
