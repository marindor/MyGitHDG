package ClassClass;

public class ActionEx {
	public static void main(String[] args) throws Exception {
		//설계 상 어떤 객체를 모르는 경우 상황에 따른 객체 생성이 필요하다.
		Class Sclass = Class.forName("ClassClass.SendAction");
		Class Rclass = Class.forName("ClassClass.ReceiveAction");
		
		//동적객체 생성
		Action action = (Action)Sclass.newInstance(); //해당 객체를 찍어내라.
		action.execute();
	}
}