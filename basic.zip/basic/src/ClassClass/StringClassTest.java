package ClassClass;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class StringClassTest {
	public static void main(String[] args) throws Exception{
		Class classInfo = Class.forName("ClassClass.Car");
		System.out.println("=================================");
		Field fields[] = classInfo.getFields();
		for(Field field :fields) {
			System.out.println(field);
			System.out.println(field.getClass().getMethods());
		}

		System.out.println("=================================");
		Method methods[] = classInfo.getMethods();
		for(Method method :methods) {
			System.out.println(method);
		}
	}
}