package oop4;

public class Book {
	//필생매
	
	//필
	private String bookName;
	private String author;
	
	//생
	public Book() {
	}
	
	public Book(String bookName, String author) {
			this.bookName = bookName;
			this.author = author;
	}
//	
	//매

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	
	void showBookInfo() {
		System.out.println(bookName+","+author);
	}
}