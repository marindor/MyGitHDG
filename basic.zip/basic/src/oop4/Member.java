package oop4;

public class Member {
	//필생매
	
	//필
	private String id;
	private String password;
	private String name;
	private String email;
	
	//생
	public Member() {

	}
	public Member(String id,String password,String name,String email) {
		this.id = id;
		this.password = password;
		this.name = name;
		this.email = email;
	}
	//매
	public void setMember(String id,String password,String name,String email) {
		this.id = id;
		this.password = password;
		this.name = name;
		this.email = email;		
	}
	public void setMemberId(String id) {
		this.id = id;
	}
	public void setMemberPassword(String password) {
		this.password = password;
	}
	public void setMemberName(String name) {
		this.name = name;
	}
	public void setMemberEmail(String email) {
		this.email = email;		
	}	
	
	public String getMember() {
		String info = this.id +","+this.password+","+this.name+","+this.email;
		return info;
	}
	public String getMemberId() {
		return this.id;
	}
	public String getMemberPassword() {
		return this.password;
	}
	public String getMemberName() {
		return this.name;
	}
	public String getMemberEmail() {
		return this.email;
	}		
}
