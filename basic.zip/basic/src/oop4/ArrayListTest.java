package oop4;

import java.util.ArrayList;

public class ArrayListTest {
	public static void main(String[] args) {
		
		ArrayList arrayList = new  ArrayList();
		
//		ArrayList<Book> arrayList = new  ArrayList<Book>();
		
		arrayList.add(new Book("책1","저자1"));
		arrayList.add(new Book("책2","저자2"));
		arrayList.add(new Book("책3","저자3"));
		
		
		System.out.println(arrayList.get(0));
		Book test = (Book)arrayList.get(0);
		System.out.println(test.getBookName());
		
		
		
		
	}
}
