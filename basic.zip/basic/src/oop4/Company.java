package oop4;

//싱글톤 패턴
public class Company {
	//필생매
	//필
	private static Company instance = new Company();
	//프로그램 전체에서 사용할 유일한 인스턴스.
	
	//생
	private Company() {
	}
	
	//매
	public static Company getInstance(){
		if(instance==null) {
			instance = new Company();
		}
		return instance;
	}


}
