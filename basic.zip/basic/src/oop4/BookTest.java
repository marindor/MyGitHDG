package oop4;

public class BookTest {
	public static void main(String[] args) {
		
		Book books[] = new Book[5];
		
		for(int i=0;i<books.length;i++) {
			books[i] = new Book("book"+(i+1),"author"+(i+1));
		}

		for(int i=0;i<books.length;i++) {
			books[i].showBookInfo();
		}
		
	}
}
