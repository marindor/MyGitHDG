package oop4;

public class CompanyTest {
	public static void main(String[] args) {
		
		//static이라 getInstance()는 다른 class와 언제든 공유 가능.
		Company myInstance1 = Company.getInstance();
		Company myInstance2 = Company.getInstance();
		
		System.out.println(System.identityHashCode(myInstance1));
		System.out.println(System.identityHashCode(myInstance2));
		
	}
}
