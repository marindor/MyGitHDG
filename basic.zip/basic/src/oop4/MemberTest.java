package oop4;

public class MemberTest {
	public static void main(String[] args) {
		
		//생성자 초기화 통합 문법
		Member member = new Member("kgb007",",1111","James","kgb@naver.com");
		//getter()로 확인
		System.out.println(member.getMember());
		
		//setter()로 수정 세팅
		member.setMember("aaa001",",2222","Kelving","koko@gamil.com");
		//getter()로 확인		
		System.out.println(member.getMember());
		
		//setter()로 id만 수정 세팅		
		member.setMemberId("root");
		//setter()로 Password만 수정 세팅		
		member.setMemberPassword("12341234");
		//setter()로 Name만 수정 세팅		
		member.setMemberName("Mr.Hong");
		//setter()로 Email만 수정 세팅		
		member.setMemberEmail("master@gmail.com");
		
		//getter()로 확인	
		System.out.println(member.getMemberId());
		System.out.println(member.getMemberPassword());
		System.out.println(member.getMemberName());
		System.out.println(member.getMemberEmail());
		
	}
	
}



