package inheritanceEx;

class Animal {
	public Animal() {
	}
	public void move() {
		System.out.println("동물이 움직임");
	}
}

class Human extends Animal{ //물려받음
	@Override //어노테이션 주석, 컴파일러에게 이 메서드는 재정의한 것이라 알려줌
	public void move() {//재정의
		System.out.println("사람이 움직임");
	}
	public void readBook() {
		System.out.println("독서하다.");
	}
}
class Tiger extends Animal{ //물려받음
	@Override //어노테이션 주석, 컴파일러에게 이 메서드는 재정의한 것이라 알려줌
	public void move() {//재정의
		System.out.println("호랑이 움직임");
	}
	public void hunt() {//재정의
		System.out.println("물어!");
	}	
}
class Eagle extends Animal{ //물려받음
	@Override //어노테이션 주석, 컴파일러에게 이 메서드는 재정의한 것이라 알려줌
	public void move() {//재정의
		System.out.println("독수리 움직임");
	}
	public void fly() {//재정의
		System.out.println("날아올라!");
	}	
}

public class AnimalTest{//java 파일 이름과 동일한 클래스명
	public AnimalTest() {
	}
	
	//아래에서 Animal animal = new Human();//자동형변환
	void animalMove(Animal animal) {
		//매개변수 자리에 부모타입 있을 경우 자식타입도 형변환되어 들어간다.
		//매개변수의 다형성이라 부른다.
		animal.move();
	}

	
	public static void main(String[] args) {
		AnimalTest ani = new AnimalTest();
		ani.animalMove(new Human());
		ani.animalMove(new Tiger());
		ani.animalMove(new Eagle());
	}
}


