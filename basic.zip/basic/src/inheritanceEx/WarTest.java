package inheritanceEx;

class Nation{
	Nation(){
	}
	void sound() {
		System.out.println("전쟁이다!");
	}
}
class Rusia extends Nation{
	Rusia(){
	}
	@Override
	void sound() {
		System.out.println("러시아가 전쟁이다");
	}
}
class Ukr extends Nation{
	Ukr(){
	}
	@Override
	void sound() {
		System.out.println("우크라이나가 전쟁이다.");
	}
}
public class WarTest {
	void WhoseWar(Nation nation){//자동형변환을 위한 떡밥
		nation.sound();
	}
	public static void main(String[] args) {
		WarTest wartest = new WarTest();
		wartest.WhoseWar(new Rusia());
		wartest.WhoseWar(new Ukr());
	}
}
