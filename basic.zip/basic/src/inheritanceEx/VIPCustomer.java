package inheritanceEx;

public class VIPCustomer extends Customer{
    //필생매
    
    //필
    private int agentID;//******
    double saleRatio;//******
    
    //생
    public VIPCustomer() { //기본생성자 초기값 세팅
        customerGrade = "VIP";
        bonusRatio = 0.05;
        saleRatio = 0.1;
        System.out.println("VIPCustomer() 생성자 호출했다.");
    }
    public VIPCustomer(int customerId,String customerName, int agentID) { 
    	super(customerId,customerName);
    	//super()는 부모에 있는 생성자다. 그 중 매개변수가 2개인 놈인 생성자랑 짝이 맞는다.
        customerGrade = "VIP";
        bonusRatio = 0.05;   
        saleRatio = 0.5;
        this.agentID = agentID;
        System.out.println("VIPCustomer(int customerId,String customerName, int agentID)생성자 호출");
    }    
    
    //매
   
    public int getAgentID() { //getter()
        return agentID;
    }
    String showVIPInfo() {
    	return super.showCustomerInfo()+" 상담원ID : "+agentID;
    }
	//부모가 가진 메소드 calcPrice(int price) 재정의(override)
	@Override   //컴파일러에게 이부분은 override한 것이라고 알려주는 주석같은 놈(annotation)
	public int calcPrice(int price) {
		bonusPoint +=price*bonusRatio;
		return price - (int)(price*saleRatio);
	}
}