package inheritanceEx;

public class OverridingTest {
	public static void main(String[] args) {
		Customer lee = new Customer(10010,"이순신");
		lee.bonusPoint=1000;
		
//		VIPCustomer 
	}
}
