package inheritanceEx;

public class Test {
    public static void main(String[] args) {

        //일반 고객부터 테스트해보자.
//        Customer lee = new Customer();
//        lee.setCustomerId(10010);
//        lee.setCustomerName("이순신");
//        lee.bonusPoint=1000;
//        System.out.println(lee.showCustomerInfo());
        
        //VIP를 테스트해볼까?
//        VIPCustomer kim = new VIPCustomer();
//        kim.setCustomerId(10020);
//        kim.setCustomerName("김유신");
//        kim.bonusPoint = 10000;
//        System.out.println(kim.showCustomerInfo());

    	VIPCustomer vc1 = new VIPCustomer(10050, "홍길동", 007);
    	System.out.println(vc1.showVIPInfo());
    }
}