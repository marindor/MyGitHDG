package inheritanceEx;

import java.util.ArrayList;

public class AnimalTest2 {
	//필생매
	//필
	ArrayList<Animal> aniList = new ArrayList<Animal>();
	
	//생
	
	
	//매  메소드는 메인메소드와 not메인메소드 형태이다.
		//메인메소드에서 다른 메소드를 호출할 수 있다.
	
	public void addAnimal(){
		aniList.add(new Human());
		aniList.add(new Tiger());
		aniList.add(new Eagle());
		
		for(Animal i : aniList) {
			i.move();
		}
	}
	
	public static void main(String[] args) {
		AnimalTest2 ani = new AnimalTest2();
		ani.addAnimal();
		ani.testCasting();
	}
	
	public void testCasting(){
		for(int i=0;i<aniList.size();i++) {
			Animal ani = aniList.get(i);
			if(ani instanceof Human) {
				Human h = (Human)ani;
				h.readBook();
			}
			else if(ani instanceof Tiger) {
				Tiger t = (Tiger)ani;
				t.hunt();
			}
			else if(ani instanceof Eagle) {
				Eagle e = (Eagle)ani;
				e.fly();
			}
			else {
				System.out.println("없는 동물이다.");
			}
		}
	}	
	
}