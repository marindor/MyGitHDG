package inheritanceEx;

public class OverrideTest2 {
	public static void main(String[] args) {
		//자동현변환 = 묵시적 형변환 = 자연스러운 형변환
		Customer vc= new VIPCustomer(10030,"나몰라",2000);
		vc.bonusPoint = 1000;
		//재정의 메서드의 호출
		System.out.println(vc.getCustomerName()+"님 "+"비용은 "+vc.calcPrice(10000)+"원" );
		
		
		
		
	}
}
