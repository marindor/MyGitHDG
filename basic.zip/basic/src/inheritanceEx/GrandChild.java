package inheritanceEx;

public class GrandChild extends Child{

}
