package inheritanceEx;

public class JibulTest {
	public static void main(String[] args) {
		Customer customer = new Customer(111,"홍길동");
		System.out.println("일반고객 ID : "+customer.customerId);
		System.out.println("일반고객 성함 : "+customer.customerName);
		System.out.println("일반고객 등급 : "+customer.customerGrade);
		System.out.println("일반고객 누적률 : "+customer.bonusRatio);
		System.out.println("==================================");
		
		VIPCustomer vipCustomer = new VIPCustomer(222,"슈퍼맨",007);
		System.out.println("특수고객 ID : "+vipCustomer.customerId);
		System.out.println("특수고객 성함 : "+vipCustomer.customerName);
		System.out.println("특수고객 등급 : "+vipCustomer.customerGrade);
		System.out.println("*특수고객 누적률 : "+vipCustomer.bonusRatio);
		System.out.println("*특수고객 할인률 : "+vipCustomer.saleRatio);
		System.out.println("==================================");	
		
		int price = 10000;
		System.out.println("제품가격 "+price+"원");
		System.out.println("---------일반고객 구매 시---------");
		System.out.println("누적포인트 : "+price*customer.bonusRatio+"원");
		System.out.println("지불 금액 : "+price);
		System.out.println("---------특수고객 구매 시---------");
		System.out.println("누적포인트 : "+price*vipCustomer.bonusRatio+"원");
		System.out.println("할인금액 : "+price*vipCustomer.saleRatio+"원");
		System.out.println("지불 금액 : "+price*(1-vipCustomer.saleRatio));
		System.out.println("==================================");
	}
}
