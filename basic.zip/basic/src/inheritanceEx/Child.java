package inheritanceEx;

public class Child extends Parent{
	int childField;
	
	void childMethod() {
		System.out.println("자식 메소드");
	}
	void eat() {
		System.out.println("자식이 밥먹는다.");
	}
}
