package inheritanceEx;

public class Parent {
	int parentField;
	
	void parentMethod() {
		System.out.println("부모 메소드");
	}
	void eat() {
		System.out.println("부모가 식사한다.");
	}
}
