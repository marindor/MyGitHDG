package inheritanceEx;

import java.util.ArrayList;

public class CustomerTest2 {
	public static void main(String[] args) {
		//2명 일반고객		//1명은 vip
		//ArrayList를 써서 5명의 고객을 추가하고 5명이 만원짜리 제품을 산다고 가정하고 고객 정보를 출력하시오.
		
		ArrayList<Customer> arrayList = new ArrayList<Customer>();
		
		Customer customer1 = new Customer(1000,"홍길동");
		arrayList.add(customer1);
		
		Customer customer2 = new Customer(1001,"오삼삼");
		arrayList.add(customer2);		
		
		VIPCustomer customer3 = new VIPCustomer(1002,"박칠칠",007);
		arrayList.add(customer3);				
		
		//배열은 향상시킨 for문 이용
		for(Customer i:arrayList) {
			System.out.println(i.showCustomerInfo());
		}
		
		System.out.println("==할인율과 보너스 포인트 계산==");
		int price = 10000;
		System.out.println("제품가격 : "+ price+"원");
		//배열은 향상시킨 for문 이용
		for(Customer i:arrayList) {
			int cost=i.calcPrice(price);
			System.out.println(i.getCustomerName()+"이 지불한 돈 : "+cost+"원");
			System.out.println("보너스포인트 : "+i.bonusPoint+"원");
		}
		
	}
}
