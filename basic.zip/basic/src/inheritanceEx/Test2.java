package inheritanceEx;

public class Test2 {
	public static void main(String[] args) {
		Parent parent1 = new Child();
		Parent parent2 = new Child();
		
		//자식 -> 부모로 형변환
		parent1.parentField =1;
		parent1.parentMethod();
		//부모 타입으로 완전히 바뀜
		//자식 것은 못씀
		//단 method override는 자식 것을 씀.
	
		
		
		
		//부모변수 -> 자식변수로 새로 변환
		//자식으로 강제 형변환
		Child change = (Child)parent2;
		change.parentField =5;
		change.parentMethod();
		change.eat();
		change.parentMethod();
		//부모 자식 필드, 메서드 모두 사용 가능
		


			
		
	}
}
