package oop3;

public class Book3 {
	
	private int age;
	private String address;
	private double weight;
	private double height;
	
	static String language = "Korean";
	static char gender = 'M';
	static double yesterday_temp = 25.7;
	static double tody_temp = 25.7;
	
	static String speaker1;//statc 블록을 위한 필드
	static String speaker2;//statc 블록을 위한 필드
	static double average;//statc 블록을 위한 필드
	static {
		speaker1 = "나는 "+language+"를 할 줄 안다.";
		speaker2 = "성별은 "+gender+"이다.";
		average = (yesterday_temp+tody_temp)/2;
	}
	
			
	
	public Book3() {
		weight = 80.5;
		height = 160.4;
		System.out.println("생성자 : 몸무게 "+weight);
		System.out.println("생성자 : 키 "+height);
	}
	
	void setAge(int age) {
		this.age = age;
	}
	int getAge() {
		return age;
	}
	void setAddress(String address) {
		this.address = address;
	}
	String getAddress() {
		return address;
	}
}
