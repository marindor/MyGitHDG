package oop3;

class Person{
	String name;
	int age;
	
	public Person() {
		this("캡틴",55);
	}
	public Person(String name, int age) {
		this.name=name;
		this.age=age;
	}
	
	public Person returnSelf() {
		return this;
	}
}

public class CallAnotherConst{
	public static void main(String[] args) {
		Person person = new Person();
		System.out.println(person.name);
		System.out.println(person.age);
		
		Person abc =person.returnSelf();
		System.out.println(abc);
		System.out.println(person);
		
	}
}