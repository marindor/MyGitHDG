package oop3;

public class Calc2 {
	//필생매
	//필
	static double pi = 3.14;
	
	//생
	public Calc2() {
	}
	
	//매
	static int plus(int num1, int num2){
		int result = num1+num2;
		return result;
	}
}
