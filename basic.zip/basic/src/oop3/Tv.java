package oop3;

public class Tv {
	//필생매
	//필
	static String company = "Samsung";
	static String model = "LCD";
	

	static String info;
	
	static {
		info=company+'-'+model;
	}
	
	//생

	//매
	public static void main(String[] args) {
		System.out.println(Tv.info);
	}

}
