package oop3;

public class Car {

	String company;
	String model="현대차";
	String color;
	int maxSpeed;
	
	int speed;
	int rpm;
	
	Body body;
	Engine engine;
	Tire tire;
	
	public Car(){
		
	}
	
	public Car(int maxSpeed){
		this.maxSpeed=maxSpeed;
	}
	public Car(int maxSpeed,String model){
		this.maxSpeed=maxSpeed;
		this.model=model;
	}
	public Car(String color,int maxSpeed){
		this.maxSpeed=maxSpeed;
		this.color=color;
	}		
	public Car(String model,String color){
		this.maxSpeed=maxSpeed;
		this.model=model;
		this.color=color;
	}	
	public Car(int maxSpeed,String model,String color){
		this.maxSpeed=maxSpeed;
		this.model=model;
		this.color=color;
	}	
}
