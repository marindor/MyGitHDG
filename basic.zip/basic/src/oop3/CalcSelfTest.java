package oop3;

public class CalcSelfTest {
	public static void main(String[] args) {
		CalcSelf calc = new CalcSelf();
		double val = 0;
		float val1=0f;
		int val2=0;
		val = calc.add(10.5, 2.3);
		System.out.println(val);
		val1 = calc.add(3f, 0);
		System.out.println(val1);
		val2= calc.add(1, 2, 3);
		System.out.println(val2);
		
		val = calc.sub(3.1, 5.0);
		System.out.println(val);
		val = calc.mul(10.5, 2.3);
		System.out.println(val);
		val = calc.div(10.5, 2.3);
		System.out.println(val);
	}
}
