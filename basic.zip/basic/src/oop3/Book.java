package oop3;

public class Book {
	//필생매
	
	//필
	private int bookid;//일단 보안상 수정을 막는 조치.
	String bookname;

	//생
	public Book() {
	}
	
	//매
	//private로 했을 때 그래도 접근하고 싶다면????
	//method를 이용한다.
	//public 메소드를 이용
	//이 메소드가 get메서드, set메서드이다.
	//getter, setter 이다.	
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}	
	public int getBookid() {
		return this.bookid;
	}		
	void setBookname(String bookname) {
		this.bookname = bookname;
	}
	String getBookname() {
		return this.bookname;
	}
}
