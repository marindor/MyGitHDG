package oop3;

public class Book1 {
	private int bookid;
	private String bookname;
	
	public Book1() {
	}
	
	void setBookid(int bookid) {
		this.bookid = bookid;
	}
	int getBookid() {
		return bookid;
	}
	void setBookname(String bookname) {
		this.bookname = bookname;
	}
	String getBookname() {
		return bookname;
	}		
}
