package oop3;

public class Book3Test {
	public static void main(String[] args) {
		
		System.out.println("======생성자======");
		System.out.println(Book3.speaker1);//생성자 없이 곧바로 static 돌진
		System.out.println(Book3.speaker2);//생성자 없이 곧바로 static 돌진
		System.out.println("어제오늘 평균온도는 "+Book3.average+"도이다");
		//생성자 없이 곧바로 static 돌진
		
		
		System.out.println("======메서드======");
		Book3 book3 = new Book3();
		book3.setAge(15);
		book3.setAddress("성남시 중원구 모란");
		System.out.println(book3.getAge());
		System.out.println(book3.getAddress());
		
	}	
}
