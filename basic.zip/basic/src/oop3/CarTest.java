package oop3;

public class CarTest {
	public static void main(String[] args) {

		Car myCar = new Car(300,"제네시스","검정");
		System.out.println(myCar.maxSpeed);
		System.out.println(myCar.model);
		System.out.println(myCar.color);
		
	}

}
