package oop3;

public class Tire {

}
