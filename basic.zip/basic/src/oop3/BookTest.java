package oop3;

public class BookTest {
	public static void main(String[] args) {
		Book book = new Book();
//		book.bookid = 1;
		book.setBookid(1);
		System.out.println(book.getBookid());
		book.setBookname("하하하");
		System.out.println(book.getBookname());


	}
}
