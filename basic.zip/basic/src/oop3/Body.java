package oop3;

public class Body {
	//집사상
}
