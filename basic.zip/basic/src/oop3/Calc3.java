package oop3;

public class Calc3 {
	//필생메
	//필
	
	
	//생

	//매
	static int plus(int a, int b) {
		int result = a+b;
		return result;
	}		
	public static void main(String[] args) {
		int result = Calc3.plus(2, 3);
		System.out.println(result);
	}
}
