package oop3;

public class Book1Test {
	public static void main(String[] args) {
		Book1 book1 = new Book1();
		
		book1.setBookid(555);
		book1.setBookname("홍길동전");
		
		System.out.println(book1.getBookid()); 
		System.out.println(book1.getBookname());
	}
}
