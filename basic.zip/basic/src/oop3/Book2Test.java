package oop3;

public class Book2Test {
	public static void main(String[] args) {
		
		Book2 book2 = new Book2();
		
		book2.setID(1111);
		book2.setName("전우치전");
		
		System.out.println(book2.getID());
		System.out.println(book2.getName());
	}
}
