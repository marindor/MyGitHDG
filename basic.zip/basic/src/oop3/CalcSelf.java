package oop3;

public class CalcSelf {
	
	//필생매 기본골격을 갖출 것
	
	public CalcSelf(){
		
	}

	//더하기
	double add(double a,double b) {
		double result = a+b;
		return result;
	}
	float add(float a,int b) {
		float result = a+b;
		return result;
	}	
	int add(int a, int b, int c) {
		int result = a+b+c;
		return result;
	}
	//빼기
	double sub(double a,double b) {
		double result = a-b;
		return result;
	}
	//곱하기
	double mul(double a,double b) {
		double result = a*b;
		return result;
	}
	//나누기
	double div(double a,double b) {
		double result = a/b;
		return result;
	}
}
