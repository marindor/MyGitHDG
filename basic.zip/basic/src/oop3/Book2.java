package oop3;

public class Book2 {
	private int id;
	private String name;
	
	public Book2() {
	}
	
	void setID(int id) {
		this.id = id;
	}
	int getID() {
		return id;
	}
	void setName(String name) {
		this.name = name;
	}
	String getName() {
		return name;
	}
	
}
