package oop3;

public class Calc2Test {
	public static void main(String[] args) {

//		Calc2 mycal = new Calc2(); //mycal(참조변수=객체=인스턴스)
//		System.out.println(mycal.pi);//인스턴스 필드
//		int result = mycal.plus(4, 5);
//		//mycal.plus() //인스턴스 메소드
//		System.out.println(result);

	System.out.println(Calc2.pi);
	Calc2.plus(1, 2);
	

	
	}
}
