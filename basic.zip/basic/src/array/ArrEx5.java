package array;

public class ArrEx5 {
	public static void main(String[] args) {
		
		//배열일 때만 가능.
		int arr[]= {1,2,3};
		for(int i:arr) {
			System.out.println(i);
		}
	}
}

