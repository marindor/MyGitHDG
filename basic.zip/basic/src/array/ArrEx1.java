package array;

public class ArrEx1 {
	public static void main(String[] args) {
		
//		double arr1[] = new double[5];
//		arr1[0]=60.5;
//		arr1[1]=77.2;
//		arr1[2]=80.4;
//		arr1[3]=90.2;
//		arr1[4]=48.1;
		
		double arr1[]= {};
		
//		
//		for(int i=0;i<5;i++) {
//			
//		}
//		
//		double sum=0;
//		
//		for(int i=0; i<5; i++) {
//			System.out.println(arr1[i]);
//			sum+=arr1[i];
//		}
//		System.out.println("합: "+sum);
//		
//		double pyung = sum/5;
//		System.out.println("평균 :" + pyung);
//		System.out.printf("%.3f", pyung);

	}
}

