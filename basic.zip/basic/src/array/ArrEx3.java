package array;

public class ArrEx3 {
	public static void main(String[] args) {
		
//		int arr[][] = new int[3][3];
//		
//		arr[0][0]=100;
//		arr[0][1]=100;
//		arr[0][2]=100;
//		
//		arr[1][0]=90;
//		arr[1][1]=90;
//		arr[1][2]=90;
//		
//		arr[2][0]=80;
//		arr[2][1]=80;
//		arr[2][2]=80;
//		
//		for(int i=0;i<3;i++) {
//			for(int j=0;j<3;j++) {
//				System.out.print("("+i+","+j+")"+" ");
//				System.out.println(arr[i][j]);
//			}
//			System.out.println();
//		}
//		
//		int arr2[][] = {{100,10,100},{90,90,90},{80,80,80}};
//		
//		System.out.println("행길이는 " + arr2.length);
//		System.out.println("열길이는 " + arr2[0].length);
//		
//		for(int i=0;i<arr2.length;i++) {
//			for(int j=0;j<arr2[0].length;j++) {
//				System.out.print("("+i+","+j+")"+" ");
//				System.out.println(arr2[i][j]);
//			}
//			System.out.println();
//		}
//		
//		int arr3[][] = {{100,100},{90},{80,80,80,100,50}};
//		System.out.println("행길이는 " + arr3.length);
//		System.out.println("열길이는 " + arr3[0].length);		
//		System.out.println("열길이는 " + arr3[1].length);
//		System.out.println("열길이는 " + arr3[2].length);
//		
//		for(int i=0;i<arr3.length;i++) {
//			for(int j=0;j<arr3[i].length;j++) {
//				System.out.print("("+i+","+j+")"+" ");
//				System.out.println(arr3[i][j]);
//			}
//			System.out.println();
//		}		

		int arr[][] =  new int[3][3];
		System.out.println("------------");
		int k=0;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				arr[i][j]=k++;
				System.out.print(arr[i][j]);
			}
			System.out.println("");
		}

		System.out.println(arr.length);
		System.out.println(arr[0].length);
		
		
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.print("("+arr[i][j]+")");
			}
			System.out.println();
		}
	}
}
