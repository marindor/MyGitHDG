package array;

public class ArrEx2 {
	public static void main(String[] args) {

		String arr[] = new String[5];
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}

		
		arr = new String[10];
		System.out.println(arr.length);
		
		System.out.println(System.identityHashCode(arr));
	}
}
