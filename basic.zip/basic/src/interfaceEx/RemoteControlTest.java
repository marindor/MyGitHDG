package interfaceEx;

public class RemoteControlTest {

	public static void main(String[] args) {
		
		//인터페이스 간접 접근 코딩
//		Audio audio = new Audio();
//		audio.tunrOn();
//		audio.setVolume(50);
//		int volume1=audio.getVolume();
//		System.out.println("오디오 볼륨 : "+volume1);
//		audio.tunrOff();
//		
//		Television television = new Television();
//		television.tunrOn();
//		television.setVolume(-100);
//		int volume2 =  television.getVolume();
//		System.out.println("텔레비젼 볼륨 : "+volume2);
//		television.tunrOff();
//		
//		System.out.println("---------------------");
		
		//인터페이스 직접 접근 코딩 null 핵심.
//		RemoteControl remotecontrol = null;
//		remotecontrol = new Audio();
//		remotecontrol.tunrOn();
//		remotecontrol.tunrOff();
//		System.out.println("---------------------");
//		remotecontrol = new Television();
//		remotecontrol.tunrOn();
//		remotecontrol.tunrOff();		
		
		RemoteControl rc1 = null;
		rc1 = new Audio();
		rc1.tunrOn();
		rc1.setMute(true);

		RemoteControl rc2 = null;
		rc2 = new Television();
		rc2.tunrOn();
		rc2.setMute(true);		
		
		
		RemoteControl.changeBatter();
	}
	

	

	
	
	

}
