package interfaceEx;

public class Audio implements RemoteControl{

	private int volume;
	private boolean mute;
	
	@Override
	public void tunrOn() {
		System.out.println("오디오 켬");
		
	}

	@Override
	public void tunrOff() {
		System.out.println("오디오 껐음");
		
	}

	@Override
	public void setVolume(int volume) {
		//볼륨이 최대값 초과시 max_volume으로 맞추기
		//볼륨이 최소값 미만시 min_volume으로 맞추기
		//그 외는 들어오는 값으로 그대로 설정
		if(volume>RemoteControl.MAX_VOLUME) {
			this.volume = RemoteControl.MAX_VOLUME;
		}else if(volume<RemoteControl.MIN_VOLUME){
			this.volume = RemoteControl.MIN_VOLUME;
		}
		else {
			this.volume = volume;
		}
	}
	@Override
	public void setMute(boolean mute) {
//		RemoteControl.super.setMute(mute);
		this.mute = mute;
		if(mute) {
			System.out.println("오디오 무음 처리");
		}else {
			System.out.println("오디오 무음 해제");
		}		
	}
	
	
	
	public int getVolume() {
		return volume;
	}
	
}
