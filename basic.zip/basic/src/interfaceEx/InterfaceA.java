package interfaceEx;

public interface InterfaceA {

}
