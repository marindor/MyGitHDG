package interfaceEx;

public interface RemoteControl {
	//상추디정
	
	//상수 필드
	final static int MAX_VOLUME=10;//상추디정 순서규칙에 따라 [final static] 원래 자동생략
				 int MIN_VOLUME=0;
	
	//추상 메서드
	abstract void tunrOn(); //상추디정 순서규칙에 따라 [abstract] 원래 자동생략
			 void tunrOff();
			 void setVolume(int volume);//볼륨조정
	
	//디폴드 메서드 : interface의 모든 구현 객체가 가지고 있는 기본 method
//	default 음소거 기능은 모두 필요, 그래서 리모트 컨틀로 인터페이스를 구현한 클래스에서 'basically 하게 필요한 기능'이다. 이런건 default로 선언
	default void setMute(boolean mute) {
		if(mute) {
			System.out.println("무음 처리");
		}else {
			System.out.println("소리 켬");
		}
	}
			 
	//정적 메서드
//	static : 클래스의 정적 메서드와 완전 동일
	static void changeBatter() {
		System.out.println("건전지 교환 끝.");
	}
}
