package interfaceEx;

public class Television implements RemoteControl{

	private int volume;
	private boolean mute;
	
	@Override
	public void tunrOn() {
		System.out.println("텔레비전 켬");
		
	}

	@Override
	public void tunrOff() {
		System.out.println("텔레비전 껐음");
		
	}

	@Override
	public void setVolume(int volume) {
		if(volume>RemoteControl.MAX_VOLUME) {
			this.volume = RemoteControl.MAX_VOLUME;
		}else if(volume<RemoteControl.MIN_VOLUME){
			this.volume = RemoteControl.MIN_VOLUME;
		}else {
			this.volume = volume;
		}	
	}
	@Override
	public void setMute(boolean mute) {
//		RemoteControl.super.setMute(mute);
		this.mute = mute;
		if(mute) {
			System.out.println("텔레비전 무음 처리");
		}else {
			System.out.println("텔레비전 무음 해제");
		}	
	}
	
	
	public int getVolume() {
		return volume;
	}
	
	
}
