package interfaceEx;

public interface InterfaceB extends InterfaceA{

}
