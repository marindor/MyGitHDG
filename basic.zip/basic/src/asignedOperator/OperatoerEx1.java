package asignedOperator;

public class OperatoerEx1 {
	
	public static void main(String[] args) {
		//기본 대입 연산자
		int num1=4;
		
		num1++;
		//int num2=num1+1;
		
		System.out.println(num1);
		//System.out.println(num2);
		
		//복합 대입 연산자
		num1 += 1; 
		//num1=num1+1; 중복을 버리면 num1+=1 그리고 +를 앞으로 당김.
		//대입 연산자를 형태를 피하기 위함.
		System.out.println(num1);
		num1 -= 1;
		System.out.println(num1);
		num1 *= 3;
		System.out.println(num1);
		num1 /= 3;
		System.out.println(num1);
	}
}
