
public interface interfaceEx3 {

}
