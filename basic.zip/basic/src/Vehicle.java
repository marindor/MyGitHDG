
public interface Vehicle {
	
	final static int speed = 120;

}
