package objectRelation;

public class Subway {
	int wayNumber;
	int passenger;
	int income;
	public Subway() {
	}
	public Subway(int wayNumber,int passenger,int income) {
		this.wayNumber= wayNumber;
		this.passenger= passenger;
		this.income= income;		
		System.out.println("지하철 이용 : "+this.wayNumber+"호선, "+this.passenger+"명탑 승, "+this.income+"원의 요금");
	}	
}
