package objectRelation;

public class Bus {
	int busId;
	int passenger;
	int income;
	public Bus() {
	}
	public Bus(int busId, int passenger, int income) {
		this.busId= busId;
		this.passenger= passenger;
		this.income= income;
		System.out.println("버스 이용 : "+this.busId+"번, "+this.passenger+"명 탑승 중, "+this.income+"원 요금");
	}	
}
