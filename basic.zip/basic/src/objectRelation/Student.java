package objectRelation;

public class Student {
	String name;
	int grade;
	int pocketMoney;
	
	public Student() {
	}
	public Student(String name,int grade,int pocketMoney) {
		this.name=name;
		this.grade=grade;
		this.pocketMoney=pocketMoney;		
		System.out.println("학생 정보 : "+name+", "+grade+"학년, "+pocketMoney+"원 소유");
	}	
	public void getBus(int income) {
		System.out.println("대중교통 요금 : "+income+"원");
		this.pocketMoney-=income;
		System.out.println("학생 잔액은 "+this.pocketMoney+"원");
	}
	public void getSubway(int income) {
		System.out.println("대중교통 요금 : "+income+"원");
		this.pocketMoney-=income;
		System.out.println("학생 잔액은 "+this.pocketMoney+"원");
	}

}
