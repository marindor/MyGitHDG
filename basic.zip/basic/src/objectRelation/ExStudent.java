package objectRelation;

public class ExStudent {
public static void main(String[] args) {
	
	Student student = new Student("홍길동",2,5000);
	Bus bus = new Bus(300,5,1300);
	Subway subway = new Subway(2,48,1800);
	System.out.println(student.pocketMoney);
	student.getBus(bus.income);
	bus.passenger++;
	student.getSubway(subway.income);
	subway.passenger++;
	
	System.out.println("버스에 "+bus.passenger+"명 탑승 중...");
	System.out.println("지하철에 "+subway.passenger+"명 탑승 중...");
	

	
	}
}
