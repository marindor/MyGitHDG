package aPackage;

class A {//default 접근제한자
	//필
	public int field1=1;
	int field2=1;
	private int field3=1;
	
	//생
	public A() {
		System.out.println("생성자부터 실행한다!");
		System.out.println(field1);
		System.out.println(field2);
		System.out.println(field3);
	}
	
	//매
	public void method1(){System.out.println("method1");}
	void method2(){System.out.println("method1");}
	private void method3(){System.out.println("method1");}	
}
