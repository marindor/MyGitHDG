package aPackage;

public class ATest {
	public static void main(String[] args) {
		A a = new A();

		
	}
}
