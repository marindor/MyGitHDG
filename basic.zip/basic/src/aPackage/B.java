package aPackage;

public class B {
	public static void main(String[] args) {
		A a = new A(); 
	}
}