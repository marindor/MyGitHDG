package inheritance_Abstract;

public class Grandeur extends CarControl{
	final public void run() {
		start("Grandeur");
		drive("Grandeur");
		stop("Grandeur");
		turnoff("Grandeur");
		washCar();
	}
	void washCar() {
		System.out.println("세차하자");
	}
}
