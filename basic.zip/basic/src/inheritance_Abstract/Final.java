package inheritance_Abstract;
//public final class A{...}
public class Final {
	
	final void add(int a, int b) {
		int result = a+b;
		System.out.println(result);
	}
}




