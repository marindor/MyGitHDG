package inheritance_Abstract;

public class PlayerTest {
	public static void main(String[] args) {
		Player player = new Player();//처음 실행시 일단 beginer
		player.play(1);
		
		AdvancedLevel advanced = new AdvancedLevel();
		player.upgradeLevel(advanced);
		player.play(2);
		
		SuperLevel supergrade = new SuperLevel();
		player.upgradeLevel(supergrade);
		player.play(3);
	}

}
