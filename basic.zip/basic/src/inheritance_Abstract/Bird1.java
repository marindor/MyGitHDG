package inheritance_Abstract;

public class Bird1 extends Animal2 {
	@Override
	void breathe() {
		
	}


}
