package inheritance_Abstract;

public abstract class Animal2 {
	abstract void breathe();

}
