package inheritance_Abstract;

public class Sonata extends CarControl{
	final public void run() {
		start("Sonata");
		drive("Sonata");
		stop("Sonata");
		turnoff("Sonata");
		washCar();
	}
	void washCar() {
		System.out.println("세차하자");
	}

}
