package inheritance_Abstract;

public class Fish extends Animal {
	//필생매
	@Override
	void breathe() {
		System.out.println("생선이 숨쉰다.");
	}
}
