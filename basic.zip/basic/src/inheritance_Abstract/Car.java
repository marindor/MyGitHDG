package inheritance_Abstract;

public abstract class Car {
	abstract void start(String car);
	abstract void drive(String car);
	abstract void stop(String car);
	abstract void turnoff(String car);
	abstract void run();
	
}