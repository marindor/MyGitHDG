package inheritance_Abstract;

public class AdvancedLevel extends PlayerLevel{
	@Override
	public void run() {
		System.out.println("중급자야 달려!");
	}
	@Override
	public void jump() {
		System.out.println("중급자 jump!");		
	}
	@Override
	public void turn() {
		System.out.println("중급자는 아직 못돌아!");		
	}
	@Override
	public void showLevelMessage() {
		System.out.println("중급자야 너는 좀만 더하면 만랩이다.");		
	}
}
