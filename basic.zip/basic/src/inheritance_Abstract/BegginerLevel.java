package inheritance_Abstract;

public class BegginerLevel extends PlayerLevel{
	public BegginerLevel() {
		
	}
	@Override
	public void run() {
		System.out.println("초보자야 달려!");
	}
	@Override
	public void jump() {
		System.out.println("초보자야 넌 점프 못해!");		
	}
	@Override
	public void turn() {
		System.out.println("초보자야 돌기 안되잖아!");		
	}
	@Override
	public void showLevelMessage() {
		System.out.println("초보자야 당신은 쪼랩이다.");		
	}
}
