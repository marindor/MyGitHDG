package inheritance_Abstract;
//public class B extends A{...}
public class Final2 extends Final {
	@Override
	void add(int a, int b) { //부모인 Final에서 add()를 final로 선언해서 에러!
		int result =a+b-1;
		System.out.println(result);
	}
	
	public static void main(String[] args) {
		Final2 test = new Final2();
		test.add(3, 4);
	}
}
