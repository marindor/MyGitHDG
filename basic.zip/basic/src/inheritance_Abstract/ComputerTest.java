package inheritance_Abstract;

public class ComputerTest {
	public static void main(String[] args) {
//		Computer computer = new Computer();//에러, abstract class는 실체화 할 수 없음
		Desktop computer1 = new Desktop();
		NoteBook computer2 = new NoteBook();
		computer1.display();
		computer1.turnOff();
		computer1.isFold();
	}
}
