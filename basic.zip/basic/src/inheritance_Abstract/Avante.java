package inheritance_Abstract;

public class Avante extends CarControl{
	final public void run() {
		start("Avante");
		drive("Avante");
		stop("Avante");
		turnoff("Avante");
		washCar();
	}
	void washCar() {
		System.out.println("세차하자");
	}
}
