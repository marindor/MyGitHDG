package inheritance_Abstract;

public class Genesis extends CarControl{
	final public void run() {
		start("Genesis");
		drive("Genesis");
		stop("Genesis");
		turnoff("Genesis");
		washCar();
	}
	void washCar() {
		System.out.println("세차하자");
	}
}
