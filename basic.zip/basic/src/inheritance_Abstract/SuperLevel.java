package inheritance_Abstract;

public class SuperLevel extends PlayerLevel{
	@Override
	public void run() {
		System.out.println("상급자야 번개같이 달려!");
	}
	@Override
	public void jump() {
		System.out.println("상급자야 대기권까지 뛰어!");		
	}
	@Override
	public void turn() {
		System.out.println("상급자야 100번 돌아!");		
	}
	@Override
	public void showLevelMessage() {
		System.out.println("상급자야 넌 만랩이야.");		
	}
}
