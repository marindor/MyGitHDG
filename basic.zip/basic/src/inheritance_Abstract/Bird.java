package inheritance_Abstract;

public class Bird extends Animal {
	//필생매
	@Override
	void breathe() {
		System.out.println("새가 숨쉰다.");
		
	}
}
