package inheritance_Abstract;

public abstract class Computer {
	
	abstract void display();
	abstract void typing();
	
	void turnOff() {	
	}
	boolean isFold() {
		return true;
	}

}
