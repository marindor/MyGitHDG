package inheritance_Abstract;

public abstract class Animal {
	//필생매
	//추상 메소드
	abstract void breathe();
}
