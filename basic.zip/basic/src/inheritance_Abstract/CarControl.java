package inheritance_Abstract;

public class CarControl extends Car {
	@Override
	void start(String car) {
		System.out.println(car+"start");
	}
	@Override
	void drive(String car) {
		System.out.println(car+"drive");		
	}
	@Override
	void stop(String car) {
		System.out.println(car+"stop");		
	}
	@Override
	void turnoff(String car) {
		System.out.println(car+"turnoff");		
	}
	@Override
	void run() {
	}

}
