package inheritance_Abstract;

public class Insec2 extends Animal2 {
	@Override
	void breathe() {
		
	}

}
