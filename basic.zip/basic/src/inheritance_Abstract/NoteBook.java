package inheritance_Abstract;

public class NoteBook extends Computer{
	@Override
	void display() {
		
	}
	@Override
	void typing() {
		
	}
	
}
