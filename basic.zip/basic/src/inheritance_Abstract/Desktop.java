package inheritance_Abstract;

public class Desktop extends Computer{
	@Override
	void display() {
		
	}
	@Override
	void typing() {
		
	}
	
}
