package inheritance_Abstract;

public class Player{
	private PlayerLevel level; //참조형 변수 생성
	
	public Player(){//실행파일 시작하자마자 동작하는 코드
		level = new BegginerLevel();
		level.showLevelMessage();
	}
	
	public PlayerLevel getLevel() {
		return level;
	}
	public void upgradeLevel(PlayerLevel level){
		this.level = level;
		level.showLevelMessage();
	}
	public void play(int count) {
		level.go(count);
	}
}
