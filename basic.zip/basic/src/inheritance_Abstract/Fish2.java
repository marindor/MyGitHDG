package inheritance_Abstract;

public class Fish2 extends Animal2 {
	@Override
	void breathe() {
		
	}
}
