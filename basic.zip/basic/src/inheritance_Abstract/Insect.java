package inheritance_Abstract;

public class Insect extends Animal {
	//필생매
	@Override
	void breathe() {
		System.out.println("곤충이 숨쉰다.");
	}
}
