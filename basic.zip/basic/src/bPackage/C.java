package bPackage;


//import aPackage.A; //<-- 에러
import aPackage.B;


public class C {
	B bbb = new B();
}
