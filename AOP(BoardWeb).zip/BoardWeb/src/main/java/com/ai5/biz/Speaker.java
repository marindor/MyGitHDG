package com.ai5.biz;

public interface Speaker {

	public abstract void volumeUP();

	public abstract void volumeDown();

}