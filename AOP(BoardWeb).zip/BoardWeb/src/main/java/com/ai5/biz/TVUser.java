package com.ai5.biz;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {
	public static void main(String[] args) {
		
		//다양성 이용
//		TV tv = new SamsungTV();
//		tv.powerOn();
//		tv.volumeUp();
//		tv.volumeDown();
//		tv.powerOff();	
		
		//1.스프링 컨테이너 구동
		
		//This package builds on the beans package to
		AbstractApplicationContext factory=new GenericXmlApplicationContext("applicationContext.xml");
		
		
		
//		LGTV ltv =new LGTV();
//		ltv.powerOn();
//		ltv.volumeUp();
//		ltv.volumeDown();
//		ltv.powerOff();
		
//		Samsung TV ltv =new Samsung();
//		stv.powerOn();
//		stv.volumeUp();
//		stv.volumeDown();
//		stv.powerOff();
//		TV tv=(TV)factory.getBean("TV");
//		tv.powerOn();
	
		
		//2.스프링 컨테이너로 부터 필요한 객체를 요청(lookup)
		
		TV stv=(TV)factory.getBean("stv");
		TV ltv=(TV)factory.getBean("ltv");
		
//		Speaker speaker=(Speaker)factory.getBean("speaker");
		
		stv.powerOn();
		ltv.powerOn();
//		stv.volumeUp();
//		stv.volumeDown();
		ltv.volumeUp();
		ltv.volumeDown();
		
	//3. spring 종료
		factory.close();		
		
	}

}
