package com.ai5.biz.common;

public class LogAdvice2 {
	
	public void printLog() {
		System.out.println("이것은 다른 로그");
	}

}