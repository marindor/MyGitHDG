package com.ai5.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

//의존성 주입을 지원하는 어노테이션 @Autowired @Qualifier @Resourcd

//@Component(value = "ltv")//이렇게 설정해 줌으로써 스프링 컨테이너는 해당 클래스를 bean으로 생성하고
public class LGTV implements TV{
	
	@Autowired //주로 변수 위에 설정하여 해당 타입의 객체를 찾아서 자동으로 할당
//	@Qualifier(value = "sony") // 객체를 만들고자 하는 객체명을 넣으면 됨
	private  Speaker speaker;
	
	public void powerOn() {
		System.out.println("LG-TV 전원켬");
	}
	
	public void powerOff() {
		System.out.println("LG-TV 전원끔");
	}

	public void volumeUp() {
		speaker.volumeUP();
//		System.out.println("LG-TV 볼륨 올림");
	}

	public void volumeDown() {
		speaker.volumeDown();
//		System.out.println("LG-TV 볼륨 내림");
	}
	
	

}