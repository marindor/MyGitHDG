package com.ai5.biz;

public interface TV {
	
	public abstract void powerOn();
	public abstract void volumeUp();
	public abstract void volumeDown();
	public abstract void powerOff();
	
	
}
