package com.ai5.biz;

import org.springframework.stereotype.Component;

//@Component(value= "stv")
public class SamsungTV implements TV{
	private Speaker speaker;
	private int price = 600000;
	
	public SamsungTV () {
		System.out.println("삼성 TV 객체1 생성");
	}
	
	public SamsungTV (SonySpeaker speaker1) {
			System.out.println("삼성 TV 객체2 생성");
		this.speaker=speaker1;
	}
	
	public SamsungTV (Speaker speaker,int price) {
			System.out.println("삼성 TV 객체3 생성");
		this.speaker=speaker;
		this.price = price;
		
	}
	
	public void powerOn() {
		System.out.println("삼성-TV 전원켬"+"가격"+price);
	}
	
	public void powerOff() {
		System.out.println("삼성-TV 전원끔");
	}

	public void volumeUp() {
//		speaker=new SonySpeaker();
		speaker.volumeUP();
//		System.out.println("삼성-TV 볼륨 올림");
	}

	public void volumeDown() {
//		speaker=new SonySpeaker();
		speaker.volumeDown();
//		System.out.println("삼성-TV 볼륨 내림");
	}
	
	

}
