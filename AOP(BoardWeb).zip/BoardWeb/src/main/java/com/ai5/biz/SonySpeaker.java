package com.ai5.biz;

import org.springframework.stereotype.Component;

//인터페이스 자동 생성 단축키 ALT+SHIFT+T 누르고
//익스트렉트 인터페이스 선택
//@Component(value = "sony")
public class SonySpeaker implements Speaker {
	
	
	
	public SonySpeaker() {
		System.out.println("SonySpeaker 객체 생성");
	}
	
	@Override
	public void volumeUP() {
		System.out.println("SonySpeaker 소리 올림");
	}
	
	@Override
	public void volumeDown() {
		System.out.println("SonySpeaker 소리 내림");		

	}
	

}
