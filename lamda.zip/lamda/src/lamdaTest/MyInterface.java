package lamdaTest;


//람다식은 하나의 메소드만 정의하기 때문에 두 개 이상의 추상 메소드를 선언한 인터페이스는 람다식으로 객체를 구현할 수 없다.
//하나의 추상 메소드를 선언한 인터페이스만이 람다식의 target type이 될 수 있다.
//이런 inteface class를 함수적 인터페이스라고 한다.
//두 개의 추상 메소드를 선언하지 않도록 체크하기 위해 @FunctionalInteface 를 쓴다. 실수 방지용.
@FunctionalInterface
public interface MyInterface {
	public int method(int num);
}

