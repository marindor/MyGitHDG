package lamdaTest;

public class Execlass {
	public static void main(String[] args) {
		MyInterface aa;
		//aa = (x)->{return (x+1);};
		aa = (x)-> (x+1);
		aa.method(5);
		System.out.println(aa.method(5));
	}
}
