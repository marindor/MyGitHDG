module lamda {
}