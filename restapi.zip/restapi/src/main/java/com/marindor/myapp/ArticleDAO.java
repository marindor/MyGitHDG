package com.marindor.myapp;

public class ArticleDAO {
	
}
