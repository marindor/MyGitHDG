module streamAndParallel {
}