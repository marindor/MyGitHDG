package com.ai5.junit;

import static org.junit.Assert.*; 

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class MyVectorTest {
	MyVector V = new MyVector();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("setUpBeforeClass 수행");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("tearDownAfterClass수행");
	}

	@Before
	public void setUp() throws Exception {
		
		System.out.println("setUp 수행");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("tearDown 수행");
	}

	@Test
	public void testIsEmpty() {
		assertTrue(V.isEmpty());
		V.addElement("abc");
		assertTrue(!V.isEmpty());
		System.out.println("testIsEmpty 수행");
	}

	@Test
	public void testContains() {
		String str1 = new String("abc");
		V.addElement(str1);
		assertTrue(V.contains(str1));
		System.out.println("testContains 수행");
	}

	@Test
	public void testIndexOf() {
		String str1 = new String("abc");
		String str2 = new String("def");
		V.addElement(str1);
		V.addElement(str2);
		assertEquals(1,V.indexOf(str2));
		System.out.println("testIndexOf 수행");
	}

	@Test
	public void testElementAt() {
		String str1 = new String("abc");
		String str2 = new String("def");
		V.addElement(str1);
		V.addElement(str2);
		assertSame(str1,V.elementAt(0));
		assertSame(str2,V.elementAt(1));
		System.out.println("testElementAt 수행");

	}

	@Test
	public void testAddElement() {
		V.addElement("abc");
		V.addElement(new Integer(1));
		assertEquals(2,V.size());
		System.out.println("testAddElement 수행");
	}

}
