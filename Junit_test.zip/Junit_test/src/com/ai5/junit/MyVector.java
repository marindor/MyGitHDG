package com.ai5.junit;

//oject 배열 만들고 배열 안에 요소있는지 체크, 각 요소 추가, 내용확인
//요소 사이즈 확인
public class MyVector {
	protected Object elementData[];
	protected int elementCount;
	
	public MyVector() {
		this(10);
	}
	
	public MyVector(int initCapacity) {
		this.elementData = new Object[initCapacity];
	}
	
	public synchronized int size() {
		return elementCount;
	}
	
	public boolean isEmpty(){
		return elementCount==0;
	}
	
	public boolean contains(Object element) {
		return indexOf(element)>=0;
	}
	
	public int indexOf(Object element) {
		for(int i=0;i<elementCount;i++) {
			if(element.equals(elementData[i])) {
				return i;
			}
		}
		return -1;
	}
	
	public synchronized Object elementAt(int index) {
		return elementData[index];
	}
	
	public void addElement(Object obj) {
		ensureCapacityHelper(elementCount+1);
		elementData[elementCount++] = obj;
		
	}
	
	private void ensureCapacityHelper(int minCapacity) {
		int oldCapacity = elementData.length;
		if(minCapacity>oldCapacity) {
			Object oldData[] = elementData;
			int newCapaciy = oldCapacity*2;
			if(newCapaciy<minCapacity) {
				newCapaciy = minCapacity;
			}
			elementData = new Object[newCapaciy];
			System.arraycopy(oldData, 0, elementData, 0, elementCount);
		}
	}
}
