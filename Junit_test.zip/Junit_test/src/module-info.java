module Junit_test {
	requires junit;
}